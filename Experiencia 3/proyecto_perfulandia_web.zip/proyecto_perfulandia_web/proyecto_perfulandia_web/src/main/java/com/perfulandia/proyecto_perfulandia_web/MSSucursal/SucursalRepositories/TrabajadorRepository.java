package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalRepositories;

import org.springframework.data.repository.CrudRepository;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Trabajador;

public interface TrabajadorRepository extends CrudRepository <Trabajador,Long> {

}
