package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Trabajador {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long idSucursal;
    private String tipoTrabajador;
    private Long idTrabajador;
    
    public Trabajador() {
    }

    public Trabajador(Long id, Long idSucursal, String tipoTrabajador, Long idTrabajador) {
        this.id = id;
        this.idSucursal = idSucursal;
        this.tipoTrabajador = tipoTrabajador;
        this.idTrabajador = idTrabajador;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getIdSucursal() {
        return idSucursal;
    }

    public void setIdSucursal(Long idSucursal) {
        this.idSucursal = idSucursal;
    }

    public String getTipoTrabajador() {
        return tipoTrabajador;
    }

    public void setTipoTrabajador(String tipoTrabajador) {
        this.tipoTrabajador = tipoTrabajador;
    }

    public Long getIdTrabajador() {
        return idTrabajador;
    }

    public void setIdTrabajador(Long idTrabajador) {
        this.idTrabajador = idTrabajador;
    }

    @Override
    public String toString() {
        return "Trabajador [id=" + id + ", idSucursal=" + idSucursal + ", tipoTrabajador=" + tipoTrabajador
                + ", idTrabajador=" + idTrabajador + "]";
    }

    

}
