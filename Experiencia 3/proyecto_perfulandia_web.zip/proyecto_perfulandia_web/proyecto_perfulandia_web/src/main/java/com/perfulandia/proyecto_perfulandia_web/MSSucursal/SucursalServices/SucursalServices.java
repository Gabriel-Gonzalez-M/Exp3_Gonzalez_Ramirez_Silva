package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalServices;

import java.util.List;
import java.util.Optional;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Sucursal;

public interface SucursalServices {

    List<Sucursal> findByAll();

    Optional<Sucursal> findById(Long id);

    Sucursal save(Sucursal unaSucursal);

    Optional <Sucursal> delete(Sucursal unaSucursal);
}
