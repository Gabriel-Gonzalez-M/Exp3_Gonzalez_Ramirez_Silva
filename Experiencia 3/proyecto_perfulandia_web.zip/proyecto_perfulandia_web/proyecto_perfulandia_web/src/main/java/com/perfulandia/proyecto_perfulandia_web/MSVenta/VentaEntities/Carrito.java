package com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaEntities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Carrito {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long idVenta;
    private Long idProducto;

    public Carrito() {
    }

    public Carrito(Long id, Long idVenta, Long idProducto) {
        this.id = id;
        this.idVenta = idVenta;
        this.idProducto = idProducto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(Long idVenta) {
        this.idVenta = idVenta;
    }

    public Long getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(Long idProducto) {
        this.idProducto = idProducto;
    }

    @Override
    public String toString() {
        return "Carrito [id=" + id + ", idVenta=" + idVenta + ", idProducto=" + idProducto + "]";
    }
    
    


}
