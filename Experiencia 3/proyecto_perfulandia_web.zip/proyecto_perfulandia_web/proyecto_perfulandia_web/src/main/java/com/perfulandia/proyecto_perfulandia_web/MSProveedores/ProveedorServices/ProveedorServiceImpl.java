package com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorServices;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorEntities.Proveedor;
import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorRepositories.ProveedorRepository;

@Service
public class ProveedorServiceImpl implements ProveedorServices {

    @Autowired
    private ProveedorRepository proveedorRepository;

    @Override
    @Transactional
    public Optional<Proveedor> delete(Proveedor unProveedor) {
        Optional<Proveedor> proveedorOptional = proveedorRepository.findById(unProveedor.getId());
        proveedorOptional.ifPresent(proveedorDb->{proveedorRepository.delete(unProveedor);});
        return proveedorOptional;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Proveedor> findByAll() {
        return (List<Proveedor>) proveedorRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Proveedor> findById(Long id) {
        return proveedorRepository.findById(id);
    }

    @Override
    @Transactional   
    public Proveedor save(Proveedor unProveedor) {
        return proveedorRepository.save(unProveedor);
    }


    
}
