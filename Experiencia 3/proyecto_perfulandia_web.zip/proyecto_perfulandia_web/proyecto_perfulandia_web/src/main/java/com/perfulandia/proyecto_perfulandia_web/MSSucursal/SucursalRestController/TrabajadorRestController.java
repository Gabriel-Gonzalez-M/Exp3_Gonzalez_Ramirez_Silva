package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalRestController;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Trabajador;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalServices.TrabajadorServices;

@RestController
@RequestMapping("api/trabajadores")
public class TrabajadorRestController {

    @Autowired
    private TrabajadorServices trabajadorservices;

    @GetMapping
    public List<Trabajador> verInventario(){
        return (List<Trabajador>) trabajadorservices.findByAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity <?> verDetalle(@PathVariable Long id){
        Optional<Trabajador> trabajadorOptional = trabajadorservices.findById(id);
        if (trabajadorOptional.isPresent()){
            return ResponseEntity.ok(trabajadorOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity <Trabajador> crear(@RequestBody Trabajador unTrabajador){
        return ResponseEntity.status(HttpStatus.CREATED).body(trabajadorservices.save(unTrabajador));

    }

    @PutMapping("/{id}")
    public ResponseEntity <?> modificarSucursal(@PathVariable Long id, @RequestBody Trabajador unTrabajador){
        Optional<Trabajador> trabajadorOptional = trabajadorservices.findById(id);
        if (trabajadorOptional.isPresent()){
            Trabajador trabajadorExiste = trabajadorOptional.get();
            trabajadorExiste.setIdSucursal(unTrabajador.getIdSucursal());
            trabajadorExiste.setIdTrabajador(unTrabajador.getIdTrabajador());
            trabajadorExiste.setTipoTrabajador(unTrabajador.getTipoTrabajador());
            Trabajador trabajadorModificado = trabajadorservices.save(trabajadorExiste);
            return ResponseEntity.ok(trabajadorModificado);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity <?> eliminar(@PathVariable Long id){
        Trabajador unTrabajador = new Trabajador();
        unTrabajador.setId(id);
        Optional<Trabajador> trabajadorOptional = trabajadorservices.delete(unTrabajador);
        if (trabajadorOptional.isPresent()){
            return ResponseEntity.ok(trabajadorOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }



}
