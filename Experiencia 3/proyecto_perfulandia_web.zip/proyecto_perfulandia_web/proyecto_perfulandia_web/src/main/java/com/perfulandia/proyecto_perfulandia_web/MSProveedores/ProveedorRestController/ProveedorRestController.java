package com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorRestController;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorEntities.Proveedor;
import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorServices.ProveedorServices;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("api/proveedor")
public class ProveedorRestController {

    @Autowired
    private ProveedorServices proveedorServices;

    @Operation(summary = "Obtener lista de proveedores", description = "Devuelve todos los proveedores disponibles")
    @ApiResponse(responseCode = "200", description = "Lista de proveedores retornada correctamente",
                 content = @Content(mediaType = "application/json", 
                 schema = @Schema(implementation = Proveedor.class)))

    @GetMapping
    public List<Proveedor> verProveedores(){
        return (List<Proveedor>) proveedorServices.findByAll();
    }

    @Operation(summary = "Obtener proveedores por ID", description = "Obtiene el detalle de un proveedores específico")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Proveedores encontrado",
                     content = @Content(mediaType = "application/json", schema = @Schema(implementation = Proveedor.class))),
        @ApiResponse(responseCode = "404", description = "Proveedores no encontrado")
    })


    @GetMapping("/{id}")
    public ResponseEntity<?> verDetaller(@PathVariable Long id){
        Optional<Proveedor> proveedorOptional = proveedorServices.findById(id);
        if (proveedorOptional.isPresent()) {
            return ResponseEntity.ok(proveedorOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }

    @Operation(summary = "Crear un nuevo proveedores", description = "Crea un proveedores con los datos proporcionados")
    @ApiResponse(responseCode = "201", description = "Proveedor creado correctamente",
                 content = @Content(mediaType = "application/json", schema = @Schema(implementation = Proveedor.class)))

    @PostMapping
    public ResponseEntity<Proveedor> crear(@RequestBody Proveedor unProveedor){
        return ResponseEntity.status(HttpStatus.CREATED).body(proveedorServices.save(unProveedor));
    }

    @Operation(summary = "Modificar proveedores por ID", description = "Modifica el detalle de un proveedor específico")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Proveedor modificado",
                     content = @Content(mediaType = "application/json", schema = @Schema(implementation = Proveedor.class))),
        @ApiResponse(responseCode = "404", description = "Proveedor no encontrado")
    })

    @PutMapping("/{id}")
    public ResponseEntity<?> modificar(@PathVariable Long id, @RequestBody Proveedor unProveedor){
        Optional<Proveedor> proveedorOptional = proveedorServices.findById(id);
        if (proveedorOptional.isPresent()) {
            Proveedor proveedorExiste = proveedorOptional.get();
            proveedorExiste.setNombre(unProveedor.getNombre());
            proveedorExiste.setApellido(unProveedor.getApellido());
            proveedorExiste.setDireccion(unProveedor.getDireccion());
            proveedorExiste.setNumeroCalle(unProveedor.getNumeroCalle());
            proveedorExiste.setComuna(unProveedor.getComuna());
            proveedorExiste.setNacionalidad(unProveedor.getNacionalidad());
            proveedorExiste.setCorreo(unProveedor.getCorreo());
            proveedorExiste.setContrasena(unProveedor.getContrasena());
            proveedorExiste.setWeb(unProveedor.getWeb());
            proveedorExiste.setHorarioApertura(unProveedor.getHorarioApertura());
            proveedorExiste.setHorarioCierre(unProveedor.getHorarioCierre());
            Proveedor proveedorModificado = proveedorServices.save(proveedorExiste);
            return ResponseEntity.ok(proveedorModificado);
        }
        return ResponseEntity.notFound().build();
    }

    @Operation(
    summary = "Elimina proveedor por ID",
    description = "Elimina un proveedor existente identificado por su ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Proveedor eliminado",
                 content = @Content(mediaType = "application/json", schema = @Schema(implementation = Proveedor.class))),
    @ApiResponse(responseCode = "404", description = "Proveedor no encontrado")})

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        Proveedor unProveedor = new Proveedor();
        unProveedor.setId(id);
        Optional<Proveedor> provedorOptional = proveedorServices.delete(unProveedor);
        if (provedorOptional.isPresent()) {
            return ResponseEntity.ok(provedorOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }
}
