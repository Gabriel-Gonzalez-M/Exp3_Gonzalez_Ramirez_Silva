package com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorRepositories;

import org.springframework.data.repository.CrudRepository;

import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorEntities.Proveedor;

public interface ProveedorRepository extends CrudRepository<Proveedor,Long>{

}
