package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalControllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Sucursal;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalRepositories.SucursalRepository;

@Controller
public class SucursalController {

    @Autowired
    SucursalRepository sucursalrepository;

    @GetMapping("/sucursal")
    public String sucursal(Model model){
        List <Sucursal> sucursales = (List <Sucursal>) sucursalrepository.findAll();
        model.addAttribute("sucursales", sucursales);
        return "sucursal";
    }

}
