package com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaRestController;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaEntities.Venta;
import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaServices.VentaServices;

@RestController
@RequestMapping("api/venta")
public class VentaRestController {

    @Autowired
    private VentaServices ventaServices;

    @GetMapping
    public List<Venta> verVentas(){
        return (List<Venta>) ventaServices.findByAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> verDetaller(@PathVariable Long id){
        Optional<Venta> ventaOptional = ventaServices.findById(id);
        if (ventaOptional.isPresent()) {
            return ResponseEntity.ok(ventaOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }


    @PostMapping
    public ResponseEntity<Venta> crear(@RequestBody Venta unaVenta){
        return ResponseEntity.status(HttpStatus.CREATED).body(ventaServices.save(unaVenta));
    }


    @PutMapping("/{id}")
    public ResponseEntity<?> modificar(@PathVariable Long id, @RequestBody Venta unaVenta){
        Optional<Venta> ventaOptional = ventaServices.findById(id);
        if (ventaOptional.isPresent()) {
            Venta ventaExiste = ventaOptional.get();
            ventaExiste.setTotal(unaVenta.getTotal());
            ventaExiste.setDescuento(unaVenta.getDescuento());
            ventaExiste.setIdCliente(unaVenta.getIdCliente());
            ventaExiste.setPresencial(unaVenta.isPresencial());
            ventaExiste.setIdEmpleado(unaVenta.getIdEmpleado());
            ventaExiste.setCodigoPromo(unaVenta.getCodigoPromo());
            ventaExiste.setIdSucursal(unaVenta.getIdSucursal());
            Venta ventaModificado = ventaServices.save(ventaExiste);
            return ResponseEntity.ok(ventaModificado);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        Venta unaVenta = new Venta();
        unaVenta.setId(id);
        Optional<Venta> ventaOptional = ventaServices.delete(unaVenta);
        if (ventaOptional.isPresent()) {
            return ResponseEntity.ok(ventaOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }

}
