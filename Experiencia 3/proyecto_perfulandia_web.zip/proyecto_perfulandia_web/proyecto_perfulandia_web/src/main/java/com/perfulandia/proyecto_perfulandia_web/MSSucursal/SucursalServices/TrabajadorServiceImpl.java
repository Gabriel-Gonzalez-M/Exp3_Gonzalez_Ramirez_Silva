package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalServices;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Trabajador;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalRepositories.TrabajadorRepository;

@Service
public class TrabajadorServiceImpl implements TrabajadorServices {

    @Autowired
    private TrabajadorRepository trabajadorrepository;

    @Override
    @Transactional
    public Optional<Trabajador> delete(Trabajador unTrabajador) {
        Optional<Trabajador> trabajadorOptional = trabajadorrepository.findById(unTrabajador.getId());
        trabajadorOptional.ifPresent(trabajadorDb ->{
            trabajadorrepository.delete(unTrabajador);
        });
        return trabajadorOptional;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Trabajador> findByAll() {
        return (List<Trabajador>) trabajadorrepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Trabajador> findById(Long id) {
        return trabajadorrepository.findById(id);
    }

    @Override
    @Transactional    
    public Trabajador save(Trabajador unTrabajador) {
        return trabajadorrepository.save(unTrabajador);
    }



    
}
