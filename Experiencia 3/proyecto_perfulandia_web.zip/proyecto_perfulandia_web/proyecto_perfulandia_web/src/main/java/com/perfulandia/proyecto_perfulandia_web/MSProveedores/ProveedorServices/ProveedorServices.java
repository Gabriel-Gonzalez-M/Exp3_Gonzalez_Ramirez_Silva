package com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorServices;

import java.util.List;
import java.util.Optional;

import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorEntities.Proveedor;



public interface ProveedorServices {

    List<Proveedor> findByAll();

    Optional<Proveedor> findById(Long id);

    Proveedor save(Proveedor unProveedor);

    Optional<Proveedor> delete(Proveedor unProveedor);
}
