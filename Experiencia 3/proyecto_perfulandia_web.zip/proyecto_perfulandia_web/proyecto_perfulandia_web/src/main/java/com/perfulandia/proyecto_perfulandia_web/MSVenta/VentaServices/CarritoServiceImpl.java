package com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaServices;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaEntities.Carrito;
import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaRepositories.CarritoRepository;

@Service
public class CarritoServiceImpl implements CarritoServices{

    @Autowired
    private CarritoRepository carritoRepository;


    @Override
    @Transactional
    public Optional<Carrito> delete(Carrito unCarrito) {
        Optional<Carrito> carritoOptional = carritoRepository.findById(unCarrito.getId());
        carritoOptional.ifPresent(carritoDb->{carritoRepository.delete(unCarrito);});
        return carritoOptional;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Carrito> findByAll() {
        return (List<Carrito>) carritoRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Carrito> findById(Long id) {
        return carritoRepository.findById(id);
    }

    @Override
    @Transactional
    public Carrito save(Carrito unCarrito) {
        return carritoRepository.save(unCarrito);
    }

    
}
