package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Inventario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long idSucursal;
    private Long idProducto;
    private int stock;

    
    public Inventario() {
    }


    public Inventario(Long id, Long idSucursal, Long idProducto, int stock) {
        this.id = id;
        this.idSucursal = idSucursal;
        this.idProducto = idProducto;
        this.stock = stock;
    }


    public Long getId() {
        return id;
    }


    public void setId(Long id) {
        this.id = id;
    }


    public Long getIdSucursal() {
        return idSucursal;
    }


    public void setIdSucursal(Long idSucursal) {
        this.idSucursal = idSucursal;
    }


    public Long getIdProducto() {
        return idProducto;
    }


    public void setIdProducto(Long idProducto) {
        this.idProducto = idProducto;
    }


    public int getStock() {
        return stock;
    }


    public void setStock(int stock) {
        this.stock = stock;
    }


    @Override
    public String toString() {
        return "Inventario [id=" + id + ", idSucursal=" + idSucursal + ", idProducto=" + idProducto + ", stock=" + stock
                + "]";
    }

    

}
