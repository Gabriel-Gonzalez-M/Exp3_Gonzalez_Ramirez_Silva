package com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaServices;

import java.util.List;
import java.util.Optional;

import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaEntities.Carrito;


public interface CarritoServices {

    List<Carrito> findByAll();

    Optional<Carrito> findById(Long id);

    Carrito save(Carrito unCarrito);

    Optional<Carrito> delete(Carrito unCarrito);
}
