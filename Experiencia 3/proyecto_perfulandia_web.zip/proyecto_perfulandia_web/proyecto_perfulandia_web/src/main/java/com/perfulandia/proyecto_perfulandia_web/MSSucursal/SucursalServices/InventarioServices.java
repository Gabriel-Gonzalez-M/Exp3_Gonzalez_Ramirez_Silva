package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalServices;

import java.util.List;
import java.util.Optional;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Inventario;

public interface InventarioServices {

    List <Inventario> findByAll();

    Optional <Inventario> findById(Long id);

    Inventario save(Inventario unInventario);

    Optional <Inventario> delete(Inventario unInventario);
}