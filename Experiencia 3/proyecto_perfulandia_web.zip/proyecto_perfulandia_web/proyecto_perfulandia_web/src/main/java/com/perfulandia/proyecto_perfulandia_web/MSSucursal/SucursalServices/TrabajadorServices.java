package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalServices;

import java.util.List;
import java.util.Optional;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Trabajador;

public interface TrabajadorServices {

    List <Trabajador> findByAll();

    Optional <Trabajador> findById(Long id);

    Trabajador save(Trabajador unTrabajador);

    Optional <Trabajador> delete(Trabajador unTrabajador);
}
