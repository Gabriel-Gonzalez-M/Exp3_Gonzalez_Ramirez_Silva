package com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaControllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaEntities.Venta;
import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaRepositories.VentaRepository;

@Controller
public class VentaController {

    @Autowired
    VentaRepository ventaRepository;

    @GetMapping("/venta")
    public String venta(Model model){
        List<Venta> ventas = (List<Venta>) ventaRepository.findAll();
        model.addAttribute("ventas", ventas);
        return "venta";
    }

}
