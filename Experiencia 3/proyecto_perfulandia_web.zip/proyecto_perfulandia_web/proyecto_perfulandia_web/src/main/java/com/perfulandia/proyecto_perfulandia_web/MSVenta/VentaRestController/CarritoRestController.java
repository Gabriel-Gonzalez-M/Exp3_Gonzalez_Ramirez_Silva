package com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaRestController;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaEntities.Carrito;
import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaServices.CarritoServices;

@RestController
@RequestMapping("api/carrito")
public class CarritoRestController {

    @Autowired
    private CarritoServices carritoServices;
    

    @GetMapping
    public List<Carrito> verCarritos(){
        return (List<Carrito>) carritoServices.findByAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> verDetaller(@PathVariable Long id){
        Optional<Carrito> carritoOptional = carritoServices.findById(id);
        if (carritoOptional.isPresent()) {
            return ResponseEntity.ok(carritoOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }


    @PostMapping
    public ResponseEntity<Carrito> crear(@RequestBody Carrito unCarrito){
        return ResponseEntity.status(HttpStatus.CREATED).body(carritoServices.save(unCarrito));
    }


    @PutMapping("/{id}")
    public ResponseEntity<?> modificar(@PathVariable Long id, @RequestBody Carrito unCarrito){
        Optional<Carrito> carritoOptional = carritoServices.findById(id);
        if (carritoOptional.isPresent()) {
            Carrito carritoExiste = carritoOptional.get();
            carritoExiste.setIdProducto(unCarrito.getIdProducto());
            carritoExiste.setIdVenta(unCarrito.getIdVenta());
            Carrito carritoModificado = carritoServices.save(carritoExiste);
            return ResponseEntity.ok(carritoModificado);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        Carrito unCarrito = new Carrito();
        unCarrito.setId(id);
        Optional<Carrito> carritoOptional = carritoServices.delete(unCarrito);
        if (carritoOptional.isPresent()) {
            return ResponseEntity.ok(carritoOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }

}
