package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities;

import java.time.LocalDate;
import java.time.LocalTime;

import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioEntities.Cuenta;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Sucursal extends Cuenta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private String codigo;
    private String direccion;
    private String ciudad;
    private String region;
    private String telefono;
    private LocalTime horarioApertura;
    private LocalTime horarioCierre;
    private String estado;
    private LocalDate fechaCreacion;
    private LocalDate fechaModificacion;
    private String responsable;
    private String tipoSucursal;
    private int aforoMaximo;
    private String servicios;
    private String observaciones;

    public Sucursal() {
    }


    public Sucursal(String correo, String contrasena, Long id, String nombre, String codigo, String direccion,
            String ciudad, String region, String telefono, LocalTime horarioApertura, LocalTime horarioCierre,
            String estado, LocalDate fechaCreacion, LocalDate fechaModificacion, String responsable,
            String tipoSucursal, int aforoMaximo, String servicios, String observaciones) {
        super(correo, contrasena);
        this.id = id;
        this.nombre = nombre;
        this.codigo = codigo;
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.region = region;
        this.telefono = telefono;
        this.horarioApertura = horarioApertura;
        this.horarioCierre = horarioCierre;
        this.estado = estado;
        this.fechaCreacion = fechaCreacion;
        this.fechaModificacion = fechaModificacion;
        this.responsable = responsable;
        this.tipoSucursal = tipoSucursal;
        this.aforoMaximo = aforoMaximo;
        this.servicios = servicios;
        this.observaciones = observaciones;
    }


    public Long getId() {
        return id;
    }


    public void setId(Long id) {
        this.id = id;
    }


    public String getNombre() {
        return nombre;
    }


    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public String getCodigo() {
        return codigo;
    }


    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }


    public String getDireccion() {
        return direccion;
    }


    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }


    public String getCiudad() {
        return ciudad;
    }


    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }


    public String getRegion() {
        return region;
    }


    public void setRegion(String region) {
        this.region = region;
    }


    public String getTelefono() {
        return telefono;
    }


    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }


    public LocalTime getHorarioApertura() {
        return horarioApertura;
    }


    public void setHorarioApertura(LocalTime horarioApertura) {
        this.horarioApertura = horarioApertura;
    }


    public LocalTime getHorarioCierre() {
        return horarioCierre;
    }


    public void setHorarioCierre(LocalTime horarioCierre) {
        this.horarioCierre = horarioCierre;
    }


    public String getEstado() {
        return estado;
    }


    public void setEstado(String estado) {
        this.estado = estado;
    }


    public LocalDate getFechaCreacion() {
        return fechaCreacion;
    }


    public void setFechaCreacion(LocalDate fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }


    public LocalDate getFechaModificacion() {
        return fechaModificacion;
    }


    public void setFechaModificacion(LocalDate fechaModificacion) {
        this.fechaModificacion = fechaModificacion;
    }


    public String getResponsable() {
        return responsable;
    }


    public void setResponsable(String responsable) {
        this.responsable = responsable;
    }


    public String getTipoSucursal() {
        return tipoSucursal;
    }


    public void setTipoSucursal(String tipoSucursal) {
        this.tipoSucursal = tipoSucursal;
    }


    public int getAforoMaximo() {
        return aforoMaximo;
    }


    public void setAforoMaximo(int aforoMaximo) {
        this.aforoMaximo = aforoMaximo;
    }


    public String getServicios() {
        return servicios;
    }


    public void setServicios(String servicios) {
        this.servicios = servicios;
    }


    public String getObservaciones() {
        return observaciones;
    }


    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }


    @Override
    public String toString() {
        return "Sucursal [id=" + id + ", nombre=" + nombre + ", codigo=" + codigo + ", direccion=" + direccion
                + ", ciudad=" + ciudad + ", region=" + region + ", telefono=" + telefono + ", horarioApertura="
                + horarioApertura + ", horarioCierre=" + horarioCierre + ", estado=" + estado + ", fechaCreacion="
                + fechaCreacion + ", fechaModificacion=" + fechaModificacion + ", responsable=" + responsable
                + ", tipoSucursal=" + tipoSucursal + ", aforoMaximo=" + aforoMaximo + ", servicios=" + servicios
                + ", observaciones=" + observaciones + "]";
    }


    


}
