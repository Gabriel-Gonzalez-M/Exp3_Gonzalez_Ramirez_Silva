package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalRestController;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Inventario;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalServices.InventarioServices;

@RestController
@RequestMapping("api/inventarios")
public class InventarioRestController {

    @Autowired
    private InventarioServices inventarioservices;

    @GetMapping
    public List<Inventario> verInventario(){
        return (List<Inventario>) inventarioservices.findByAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity <?> verDetalle(@PathVariable Long id){
        Optional<Inventario> inventarioOptional = inventarioservices.findById(id);
        if (inventarioOptional.isPresent()){
            return ResponseEntity.ok(inventarioOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity <Inventario> crear(@RequestBody Inventario unInventario){
        return ResponseEntity.status(HttpStatus.CREATED).body(inventarioservices.save(unInventario));

    }

    @PutMapping("/{id}")
    public ResponseEntity <?> modificarSucursal(@PathVariable Long id, @RequestBody Inventario unInventario){
        Optional <Inventario> inventarioOptional = inventarioservices.findById(id);
        if (inventarioOptional.isPresent()){
            Inventario inventarioExiste = inventarioOptional.get();
            inventarioExiste.setIdProducto(unInventario.getIdProducto());
            inventarioExiste.setIdSucursal(unInventario.getIdSucursal());
            inventarioExiste.setStock(unInventario.getStock());
            Inventario inventarioModificado = inventarioservices.save(inventarioExiste);
            return ResponseEntity.ok(inventarioModificado);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity <?> eliminar(@PathVariable Long id){
        Inventario unInventario = new Inventario();
        unInventario.setId(id);
        Optional<Inventario> inventarioOptional = inventarioservices.delete(unInventario);
        if (inventarioOptional.isPresent()){
            return ResponseEntity.ok(inventarioOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }


}
