package com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorEntities;

import java.time.LocalTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Proveedor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private String apellido;
    private String direccion;
    private int numeroCalle;
    private String comuna;
    private String nacionalidad;
    private int telefono;
    private String correo;
    private String contrasena;
    private String web;
    private LocalTime horarioApertura;
    private LocalTime horarioCierre;

    public Proveedor() {
    }

    public Proveedor(Long id, String nombre, String apellido, String direccion, int numeroCalle, String comuna,
            String nacionalidad, int telefono, String correo, String contrasena, String web, LocalTime horarioApertura,
            LocalTime horarioCierre) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.numeroCalle = numeroCalle;
        this.comuna = comuna;
        this.nacionalidad = nacionalidad;
        this.telefono = telefono;
        this.correo = correo;
        this.contrasena = contrasena;
        this.web = web;
        this.horarioApertura = horarioApertura;
        this.horarioCierre = horarioCierre;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getNumeroCalle() {
        return numeroCalle;
    }

    public void setNumeroCalle(int numeroCalle) {
        this.numeroCalle = numeroCalle;
    }

    public String getComuna() {
        return comuna;
    }

    public void setComuna(String comuna) {
        this.comuna = comuna;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getWeb() {
        return web;
    }

    public void setWeb(String web) {
        this.web = web;
    }

    public LocalTime getHorarioApertura() {
        return horarioApertura;
    }

    public void setHorarioApertura(LocalTime horarioApertura) {
        this.horarioApertura = horarioApertura;
    }

    public LocalTime getHorarioCierre() {
        return horarioCierre;
    }

    public void setHorarioCierre(LocalTime horarioCierre) {
        this.horarioCierre = horarioCierre;
    }

    @Override
    public String toString() {
        return "Proveedor [id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", direccion=" + direccion
                + ", numeroCalle=" + numeroCalle + ", comuna=" + comuna + ", nacionalidad=" + nacionalidad
                + ", telefono=" + telefono + ", correo=" + correo + ", contrasena=" + contrasena + ", web=" + web
                + ", horarioApertura=" + horarioApertura + ", horarioCierre=" + horarioCierre + "]";
    }

    
    


}
