package com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorControllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorEntities.ProductoProv;
import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorRepositories.ProductoProvRepository;

@Controller
public class ProductoProvController {

    @Autowired
    ProductoProvRepository productoProvRepository;

    @GetMapping("/productoprov")
    public String productoProv(Model model){
        List<ProductoProv> productosProv = (List<ProductoProv>) productoProvRepository.findAll();
        model.addAttribute("productosprov", productosProv);
        return "productoProv";
    }

}
