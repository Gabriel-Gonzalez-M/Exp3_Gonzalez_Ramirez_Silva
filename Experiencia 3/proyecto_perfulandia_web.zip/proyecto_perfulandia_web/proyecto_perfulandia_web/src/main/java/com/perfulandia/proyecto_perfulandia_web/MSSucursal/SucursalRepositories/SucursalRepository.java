package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalRepositories;

import org.springframework.data.repository.CrudRepository;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Sucursal;

public interface SucursalRepository extends CrudRepository <Sucursal, Long> {

}



