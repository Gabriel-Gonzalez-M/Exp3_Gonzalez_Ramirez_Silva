package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalRestController;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Sucursal;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalServices.SucursalServices;

@RestController
@RequestMapping ("api/sucursales")
public class SucursalRestController {

    @Autowired
    private SucursalServices sucursalservices;

    @GetMapping
    public List <Sucursal> verSucursal(){
        return (List <Sucursal>)sucursalservices.findByAll();

    }

    @GetMapping("/{id}")
    public ResponseEntity <?> verDetalle(@PathVariable Long id){
        Optional<Sucursal> sucursalOptional = sucursalservices.findById(id);
        if (sucursalOptional.isPresent()){
            return ResponseEntity.ok(sucursalOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity <Sucursal> crear(@RequestBody Sucursal unaSucursal){
        return ResponseEntity.status(HttpStatus.CREATED).body(sucursalservices.save(unaSucursal));

    }

    @PutMapping("/{id}")
    public ResponseEntity <?> modificarSucursal(@PathVariable Long id, @RequestBody Sucursal unaSucursal){
        Optional <Sucursal> sucursalOptional = sucursalservices.findById(id);
        if (sucursalOptional.isPresent()){
            Sucursal sucursalExiste = sucursalOptional.get();
            sucursalExiste.setNombre(unaSucursal.getNombre());
            sucursalExiste.setCodigo(unaSucursal.getCodigo());
            sucursalExiste.setDireccion(unaSucursal.getDireccion());
            sucursalExiste.setCiudad(unaSucursal.getCiudad());
            sucursalExiste.setRegion(unaSucursal.getRegion());
            sucursalExiste.setTelefono(unaSucursal.getTelefono());
            sucursalExiste.setCorreo(unaSucursal.getCorreo());
            sucursalExiste.setContrasena(unaSucursal.getContrasena());
            sucursalExiste.setHorarioApertura(unaSucursal.getHorarioApertura());
            sucursalExiste.setHorarioCierre(unaSucursal.getHorarioCierre());
            sucursalExiste.setEstado(unaSucursal.getEstado());
            sucursalExiste.setFechaCreacion(unaSucursal.getFechaCreacion());
            sucursalExiste.setFechaModificacion(unaSucursal.getFechaModificacion());
            sucursalExiste.setResponsable(unaSucursal.getResponsable());
            sucursalExiste.setTipoSucursal(unaSucursal.getTipoSucursal());
            sucursalExiste.setAforoMaximo(unaSucursal.getAforoMaximo());
            sucursalExiste.setServicios(unaSucursal.getServicios());
            sucursalExiste.setObservaciones(unaSucursal.getObservaciones());
            Sucursal sucursalModificada = sucursalservices.save(sucursalExiste);
            return ResponseEntity.ok(sucursalModificada);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity <?> eliminar(@PathVariable Long id){
        Sucursal unaSucursal = new Sucursal();
        unaSucursal.setId(id);
        Optional<Sucursal> sucursalOptional = sucursalservices.delete(unaSucursal);
        if (sucursalOptional.isPresent()){
            return ResponseEntity.ok(sucursalOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }
}
