package com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaEntities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Venta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private int total;
    private float descuento;
    private Long idCliente;
    private boolean presencial;
    private Long idEmpleado;
    private String codigoPromo;
    private Long idSucursal;
    
    public Venta() {
    }

    public Venta(Long id, int total, float descuento, Long idCliente, boolean presencial, Long idEmpleado,
            String codigoPromo, Long idSucursal) {
        this.id = id;
        this.total = total;
        this.descuento = descuento;
        this.idCliente = idCliente;
        this.presencial = presencial;
        this.idEmpleado = idEmpleado;
        this.codigoPromo = codigoPromo;
        this.idSucursal = idSucursal;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public float getDescuento() {
        return descuento;
    }

    public void setDescuento(float descuento) {
        this.descuento = descuento;
    }

    public Long getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Long idCliente) {
        this.idCliente = idCliente;
    }

    public boolean isPresencial() {
        return presencial;
    }

    public void setPresencial(boolean presencial) {
        this.presencial = presencial;
    }

    public Long getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(Long idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getCodigoPromo() {
        return codigoPromo;
    }

    public void setCodigoPromo(String codigoPromo) {
        this.codigoPromo = codigoPromo;
    }

    public Long getIdSucursal() {
        return idSucursal;
    }

    public void setIdSucursal(Long idSucursal) {
        this.idSucursal = idSucursal;
    }

    @Override
    public String toString() {
        return "Venta [id=" + id + ", total=" + total + ", descuento=" + descuento + ", idCliente=" + idCliente
                + ", presencial=" + presencial + ", idEmpleado=" + idEmpleado + ", codigoPromo=" + codigoPromo
                + ", idSucursal=" + idSucursal + "]";
    }

    

    
    
}
