package com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorControllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorEntities.Proveedor;
import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorRepositories.ProveedorRepository;

@Controller
public class ProveedorController {

    @Autowired
    ProveedorRepository proveedorrepository;

    @GetMapping("/proveedor")
    public String proveedor(Model model){
        List <Proveedor> proveedores = (List<Proveedor>) proveedorrepository.findAll();
        model.addAttribute("proveedores", proveedores);
        return "proveedor";
    }

}
