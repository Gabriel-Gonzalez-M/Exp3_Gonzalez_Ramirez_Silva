package com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaRepositories;

import org.springframework.data.repository.CrudRepository;

import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaEntities.Venta;

public interface VentaRepository extends CrudRepository<Venta,Long>{

}
