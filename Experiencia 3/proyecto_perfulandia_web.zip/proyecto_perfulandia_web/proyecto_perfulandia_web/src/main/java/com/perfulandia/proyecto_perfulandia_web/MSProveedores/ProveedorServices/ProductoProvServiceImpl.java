package com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorServices;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorEntities.ProductoProv;
import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorRepositories.ProductoProvRepository;

@Service
public class ProductoProvServiceImpl implements ProductosProvServices{

    @Autowired
    private ProductoProvRepository productoProvRepository;

    @Override
    @Transactional
    public Optional<ProductoProv> delete(ProductoProv unProductoProv) {
        Optional<ProductoProv> productoProvOptional = productoProvRepository.findById(unProductoProv.getId());
        productoProvOptional.ifPresent(productoProvDb->{productoProvRepository.delete(unProductoProv);});
        return productoProvOptional;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProductoProv> findByAll() {
        return (List<ProductoProv>) productoProvRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ProductoProv> findById(Long id) {
        return productoProvRepository.findById(id);
    }

    @Override
    @Transactional    
    public ProductoProv save(ProductoProv unProductoProv) {
        return productoProvRepository.save(unProductoProv);
    }


    

}
