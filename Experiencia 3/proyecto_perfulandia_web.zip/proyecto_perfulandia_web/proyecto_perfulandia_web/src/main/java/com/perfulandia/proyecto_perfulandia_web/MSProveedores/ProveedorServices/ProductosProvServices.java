package com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorServices;

import java.util.List;
import java.util.Optional;

import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorEntities.ProductoProv;



public interface ProductosProvServices {

    List<ProductoProv> findByAll();

    Optional<ProductoProv> findById(Long id);

    ProductoProv save(ProductoProv unProductoProv);

    Optional<ProductoProv> delete(ProductoProv unProductoProv);
}
