package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalControllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Inventario;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalRepositories.InventarioRepository;

@Controller
public class InventarioController {

    @Autowired
    InventarioRepository inventariorepository;

    @GetMapping("/inventario")
    public String inventario(Model model){
        List <Inventario> inventarios = (List <Inventario>) inventariorepository.findAll();
        model.addAttribute("inventarios", inventarios);
        return "inventario";
    }

}
