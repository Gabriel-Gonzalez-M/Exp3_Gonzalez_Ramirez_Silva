package com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorRepositories;

import org.springframework.data.repository.CrudRepository;

import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorEntities.ProductoProv;

public interface ProductoProvRepository extends CrudRepository<ProductoProv,Long>{

}
