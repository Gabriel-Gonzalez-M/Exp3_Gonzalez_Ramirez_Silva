package com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorEntities;

import java.time.LocalTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ProductoProv {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long idProducto;
    private Long idProveedor;
    private int precio;
    private LocalTime tiempoEnvio;
    private int cantProdxMayor;
    
    public ProductoProv() {
    }

    public ProductoProv(Long id, Long idProducto, Long idProveedor, int precio, LocalTime tiempoEnvio,
            int cantProdxMayor) {
        this.id = id;
        this.idProducto = idProducto;
        this.idProveedor = idProveedor;
        this.precio = precio;
        this.tiempoEnvio = tiempoEnvio;
        this.cantProdxMayor = cantProdxMayor;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(Long idProducto) {
        this.idProducto = idProducto;
    }

    public Long getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(Long idProveedor) {
        this.idProveedor = idProveedor;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public LocalTime getTiempoEnvio() {
        return tiempoEnvio;
    }

    public void setTiempoEnvio(LocalTime tiempoEnvio) {
        this.tiempoEnvio = tiempoEnvio;
    }

    public int getCantProdxMayor() {
        return cantProdxMayor;
    }

    public void setCantProdxMayor(int cantProdxMayor) {
        this.cantProdxMayor = cantProdxMayor;
    }

    @Override
    public String toString() {
        return "ProductoProv [id=" + id + ", idProducto=" + idProducto + ", idProveedor=" + idProveedor + ", precio="
                + precio + ", tiempoEnvio=" + tiempoEnvio + ", cantProdxMayor=" + cantProdxMayor + "]";
    }

    




}
