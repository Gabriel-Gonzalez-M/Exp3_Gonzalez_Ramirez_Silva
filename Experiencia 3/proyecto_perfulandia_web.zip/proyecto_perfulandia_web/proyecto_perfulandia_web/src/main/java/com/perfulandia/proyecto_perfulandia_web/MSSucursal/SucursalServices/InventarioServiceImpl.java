package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalServices;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Inventario;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalRepositories.InventarioRepository;

@Service
public class InventarioServiceImpl implements InventarioServices {

    @Autowired
    private InventarioRepository inventariorepository;


    @Override
    @Transactional
    public Optional<Inventario> delete(Inventario unInventario) {
        Optional<Inventario> inventarioOptional = inventariorepository.findById(unInventario.getId());
        inventarioOptional.ifPresent(inventarioDb ->{
            inventariorepository.delete(unInventario);
        });
        return inventarioOptional;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Inventario> findByAll() {
        return (List<Inventario>) inventariorepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Inventario> findById(Long id) {
        return inventariorepository.findById(id);
    }

    @Override
    @Transactional
    public Inventario save(Inventario unInventario) {
        return inventariorepository.save(unInventario);
    }



    
}
