package com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalControllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Trabajador;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalRepositories.TrabajadorRepository;

@Controller
public class TrabajadorController {

    @Autowired
    TrabajadorRepository trabajadorrepository;


    @GetMapping("/trabajador")
    public String trabajador(Model model){
        List <Trabajador> trabajadores = (List <Trabajador>) trabajadorrepository.findAll();
        model.addAttribute("trabajadores", trabajadores);
        return "trabajador";
    }
}
