package com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorRestController;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorEntities.ProductoProv;
import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorServices.ProductosProvServices;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("api/productoprov")
public class ProductoProvRestController {

    @Autowired
    private ProductosProvServices productosProvServices;

    @Operation(summary = "Obtener lista de productos proveedores", description = "Devuelve todos los productos proveedores disponibles")
    @ApiResponse(responseCode = "200", description = "Lista de producto proveedores retornada correctamente",
                 content = @Content(mediaType = "application/json", 
                 schema = @Schema(implementation = ProductoProv.class)))


    @GetMapping
    public List<ProductoProv> verProductosProv(){
        return (List<ProductoProv>) productosProvServices.findByAll();
    }

    @Operation(summary = "Obtener producto proveedores por ID", description = "Obtiene el detalle de un producto proveedores específico")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Producto proveedores encontrado",
                     content = @Content(mediaType = "application/json", schema = @Schema(implementation = ProductoProv.class))),
        @ApiResponse(responseCode = "404", description = "Producto proveedores no encontrado")
    })



    @GetMapping("/{id}")
    public ResponseEntity<?> verDetaller(@PathVariable Long id){
        Optional<ProductoProv> productoProvOptional = productosProvServices.findById(id);
        if (productoProvOptional.isPresent()) {
            return ResponseEntity.ok(productoProvOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }

    @Operation(summary = "Crear un nuevo producto proveedores", description = "Crea un producto proveedores con los datos proporcionados")
    @ApiResponse(responseCode = "201", description = "Producto creado correctamente",
                 content = @Content(mediaType = "application/json", schema = @Schema(implementation = ProductoProv.class)))


    @PostMapping
    public ResponseEntity<ProductoProv> crear(@RequestBody ProductoProv unProductoProv){
        return ResponseEntity.status(HttpStatus.CREATED).body(productosProvServices.save(unProductoProv));
    }

    @Operation(summary = "Modificar producto proveedores por ID", description = "Modifica el detalle de un producto proveedor específico")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Producto proveedor modificado",
                     content = @Content(mediaType = "application/json", schema = @Schema(implementation = ProductoProv.class))),
        @ApiResponse(responseCode = "404", description = "Producto proveedor no encontrado")
    })




    @PutMapping("/{id}")
    public ResponseEntity<?> modificar(@PathVariable Long id, @RequestBody ProductoProv unProductoProv){
        Optional<ProductoProv> productoProvOptional = productosProvServices.findById(id);
        if (productoProvOptional.isPresent()) {
            ProductoProv productoProvExiste = productoProvOptional.get();
            productoProvExiste.setIdProducto(unProductoProv.getIdProducto());
            productoProvExiste.setIdProveedor(unProductoProv.getIdProveedor());
            productoProvExiste.setPrecio(unProductoProv.getPrecio());
            productoProvExiste.setCantProdxMayor(unProductoProv.getCantProdxMayor());
            productoProvExiste.setTiempoEnvio(unProductoProv.getTiempoEnvio());
            ProductoProv productoProvModificado = productosProvServices.save(productoProvExiste);
            return ResponseEntity.ok(productoProvModificado);
        }
        return ResponseEntity.notFound().build();
    }

    @Operation(
    summary = "Elimina producto proveedor por ID",
    description = "Elimina un producto proveedor existente identificado por su ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Producto proveedor eliminado",
                 content = @Content(mediaType = "application/json", schema = @Schema(implementation = ProductoProv.class))),
    @ApiResponse(responseCode = "404", description = "Producto proveedor no encontrado")})

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        ProductoProv unProductoProv = new ProductoProv();
        unProductoProv.setId(id);
        Optional<ProductoProv> productoProvOptional = productosProvServices.delete(unProductoProv);
        if (productoProvOptional.isPresent()) {
            return ResponseEntity.ok(productoProvOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }
}
