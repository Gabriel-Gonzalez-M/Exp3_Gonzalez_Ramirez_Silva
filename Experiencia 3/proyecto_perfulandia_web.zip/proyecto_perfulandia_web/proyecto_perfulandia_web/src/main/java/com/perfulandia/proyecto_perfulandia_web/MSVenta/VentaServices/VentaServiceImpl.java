package com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaServices;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaEntities.Venta;
import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaRepositories.VentaRepository;

@Service
public class VentaServiceImpl implements VentaServices{

    @Autowired
    private VentaRepository ventaRepository;

    @Override
    @Transactional
    public Optional<Venta> delete(Venta unaVenta) {
        Optional<Venta> ventaOptional = ventaRepository.findById(unaVenta.getId());
        ventaOptional.ifPresent(ventaDb->{ventaRepository.delete(unaVenta);});
        return ventaOptional;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Venta> findByAll() {
        return (List<Venta>) ventaRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Venta> findById(Long id) {
        return ventaRepository.findById(id);
    }

    @Override
    @Transactional   
    public Venta save(Venta unaVenta) {
        return ventaRepository.save(unaVenta);
    }

    
}
