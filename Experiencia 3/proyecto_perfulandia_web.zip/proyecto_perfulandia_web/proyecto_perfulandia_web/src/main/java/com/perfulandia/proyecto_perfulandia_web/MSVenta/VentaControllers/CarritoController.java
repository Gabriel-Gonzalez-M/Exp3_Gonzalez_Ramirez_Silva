package com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaControllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaEntities.Carrito;
import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaRepositories.CarritoRepository;

@Controller
public class CarritoController {

    @Autowired
    CarritoRepository carritoRepository;

    @GetMapping("/carrito")
    public String carrito(Model model){
        List <Carrito> carritos = (List<Carrito>) carritoRepository.findAll();
        model.addAttribute("carritos", carritos);
        return "carrito";
    }

}
