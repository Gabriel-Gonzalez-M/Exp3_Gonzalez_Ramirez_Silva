package com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaServices;

import java.util.List;
import java.util.Optional;

import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaEntities.Venta;



public interface VentaServices {

    List<Venta> findByAll();

    Optional<Venta> findById(Long id);

    Venta save(Venta unaVenta);

    Optional<Venta> delete(Venta unaVenta);
}
