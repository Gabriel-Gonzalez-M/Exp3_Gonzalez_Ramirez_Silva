package com.perfulandia.proyecto_perfulandia_web.MSUsuariosTest.UsuariosRestControllerTest;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioEntities.Empleado;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioServices.EmpleadoServicesImpl;

@SpringBootTest
@AutoConfigureMockMvc
public class EmpleadoRestControllerTest {

     @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private EmpleadoServicesImpl empleadoServicesImpl;

    private List<Empleado> empleadoLista;

    @Test
    public void verEmpleadosTest() throws Exception{
        when(empleadoServicesImpl.findByAll()).thenReturn(empleadoLista);
        mockMvc.perform(get("/api/empleados")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    }



    @Test
    public void verUnEmpleado() throws Exception {

    Empleado verUnEmpleado = new Empleado(
        33333333,               // rut
        '3',                    // dv
        "Miyarai",              // pnombre
        "Camila",               // snombre
        "Gomez",                // apPaterno
        "Sepulveda",            // apMaterno
        99999991,               // teléfono
        LocalDate.of(1993, 2, 10),   // nacimiento
        "Empleado",             // permiso
        1L,                     // id
        LocalDate.of(2024, 5, 10),   // fechaIngreso
        "Activo",               // estado
        "Empleado",             // cargo
        "Mañana"                // turno
    );

    when(empleadoServicesImpl.findById(1L))
        .thenReturn(Optional.of(verUnEmpleado));
    mockMvc.perform(get("/api/empleados/1")               
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    verify(empleadoServicesImpl).findById(1L);
    }

    @Test
    public void empleadoNoExiste() throws Exception{
        when(empleadoServicesImpl.findById(100L)).thenReturn(Optional.empty());
        mockMvc.perform(get("/api/empleados/100")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isNotFound());

    }


    @Test
    public void crearEmpleadoTest() throws Exception {

    Empleado empleadoRequest = new Empleado(
        33333333, 
        '3',                 // rut, dv
        "Miyarai",
         "Camila",           // pnombre, snombre
        "Gomez", 
        "Sepulveda",          // apPaterno, apMaterno
        99999991,                      // teléfono
        LocalDate.of(1993, 2, 10),     // nacimiento
        "Empleado",                    // permiso
        null,                          // id  -> null al crear
        LocalDate.of(2024, 5, 10),     // fechaIngreso
        "Activo",                      // estado
        "Empleado",                    // cargo
        "Mañana"                       // turno
    );

    Empleado empleadoResponse = new Empleado(
        33333333,
        '3', 
        "Miyarai", 
        "Camila",
        "Gomez", 
        "Sepulveda", 
        99999991,
        LocalDate.of(1993, 2, 10), 
        "Empleado",
        9L,                             
        LocalDate.of(2024, 5, 10),
        "Activo", 
        "Empleado", 
        "Mañana"
    );

    when(empleadoServicesImpl.save(any(Empleado.class)))
        .thenReturn(empleadoResponse);
    mockMvc.perform(post("/api/empleados")                 
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(empleadoRequest)))
            .andExpect(status().isCreated());             
    }


    @Test
    public void modificarEmpleadoTest() throws Exception {

    Empleado empleadoActualizadoRequest = new Empleado(
        33333333, 
        '3', 
        "Miyarai", 
        "Camila",
        "Gomez", 
        "Sepulveda", 
        99999991,
        LocalDate.of(1993, 2, 10), 
        "Empleado",
        1L, LocalDate.of(2024, 5, 10),
        "Activo", 
        "Supervisor", 
        "Tarde"
    );

    Empleado empleadoActualizadoResponse = new Empleado(
        33333333, 
        '3', 
        "Miyarai", 
        "Camila",
        "Gomez", 
        "Sepulveda", 
        99999991,
        LocalDate.of(1993, 2, 10), 
        "Empleado",
        1L, LocalDate.of(2024, 5, 10),
        "Activo", 
        "Supervisor", 
        "Tarde"
    );


    Empleado empleadoExistente = new Empleado(
        33333333, 
        '3', 
        "Miyarai", 
        "Camila",
        "Gomez", 
        "Sepulveda", 
        99999991,
        LocalDate.of(1993, 2, 10), 
        "Empleado",
        1L, LocalDate.of(2024, 5, 10),
        "Activo", 
        "Empleado", 
        "Mañana"
    );

    when(empleadoServicesImpl.findById(1L)).thenReturn(Optional.of(empleadoExistente));
    when(empleadoServicesImpl.save(any(Empleado.class))).thenReturn(empleadoActualizadoResponse);
    mockMvc.perform(put("/api/empleados/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(empleadoActualizadoRequest)))
            .andExpect(status().isOk());
    }




    @Test
    public void eliminarEmpleadoTest() throws Exception {


    Empleado empleadoAEliminar = new Empleado(
        33333333, 
        '3',                 // rut, dv
        "Miyarai", 
        "Camila",           // pnombre, snombre
        "Gomez", 
        "Sepulveda",          // apPaterno, apMaterno
        99999991,                      // teléfono
        LocalDate.of(1993, 2, 10),     // nacimiento
        "Empleado",                    // permiso
        1L,                            // id
        LocalDate.of(2024, 5, 10),     // fechaIngreso
        "Activo",                      // estado
        "Empleado",                    // cargo
        "Mañana"                       // turno
    );

    when(empleadoServicesImpl.delete(any(Empleado.class)))
        .thenReturn(Optional.of(empleadoAEliminar));
    mockMvc.perform(delete("/api/empleados/1")     
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk());          

    
}




    



}
