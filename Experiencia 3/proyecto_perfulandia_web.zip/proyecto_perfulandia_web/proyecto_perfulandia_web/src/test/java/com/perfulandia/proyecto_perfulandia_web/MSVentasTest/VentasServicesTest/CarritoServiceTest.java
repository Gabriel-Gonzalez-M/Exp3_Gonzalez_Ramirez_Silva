package com.perfulandia.proyecto_perfulandia_web.MSVentasTest.VentasServicesTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaEntities.Carrito;
import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaRepositories.CarritoRepository;
import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaServices.CarritoServiceImpl;

@SpringBootTest
public class CarritoServiceTest {

    @Mock
    private CarritoRepository carritoRepository;

    @InjectMocks
    private CarritoServiceImpl carritoServiceImpl;

    private Carrito carrito;

    @BeforeEach
    public void Iniciar(){
        carrito = new Carrito(1L, 1L, 1L);
    }

    @Test
    public void findByAllTest(){
        List<Carrito> lista = Arrays.asList(carrito);
        when(carritoRepository.findAll()).thenReturn(lista);
        List<Carrito> resultado = carritoServiceImpl.findByAll();
        assertEquals(1, resultado.size());
        verify(carritoRepository).findAll();

    }

    @Test
    public void findByIdTest(){
        when(carritoRepository.findById(1L)).thenReturn(Optional.of(carrito));
        Optional<Carrito> resultado = carritoServiceImpl.findById(1L);
        assertTrue(resultado.isPresent());
        assertEquals(1L, resultado.get().getIdVenta());
        verify(carritoRepository).findById(1L);
    }

    @Test
    public void saveTest(){
        when(carritoRepository.save(any(Carrito.class))).thenReturn(carrito);
        Carrito resultado = carritoServiceImpl.save(carrito);
        assertNotNull(resultado);
        assertEquals(1L, resultado.getIdVenta());
        verify(carritoRepository).save(carrito);
    }

    @Test
    public void deleteFuncionaTest() {
        when(carritoRepository.findById(1L)).thenReturn(Optional.of(carrito));
        Optional<Carrito> resultado = carritoServiceImpl.delete(carrito);
        assertTrue(resultado.isPresent());
        assertEquals(carrito, resultado.get());
        verify(carritoRepository).delete(carrito);
    }

    @Test
    public void deleteNoFuncionaTest() {
        when(carritoRepository.findById(1L)).thenReturn(Optional.empty());
        Optional<Carrito> resultado = carritoServiceImpl.delete(carrito);
        assertTrue(resultado.isEmpty());
        verify(carritoRepository).findById(1L);
        verify(carritoRepository, never()).delete(any(Carrito.class)); 
    }



}
