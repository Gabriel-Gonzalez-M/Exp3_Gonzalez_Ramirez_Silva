package com.perfulandia.proyecto_perfulandia_web.MSUsuariosTest.UsuariosServicesTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioEntities.Cliente;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioRepositories.ClienteRepository;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioServices.ClienteServiceImpl;

@SpringBootTest
public class ClienteServiceTest {

    @Mock
    private ClienteRepository clienteRepository;

    @InjectMocks
    private ClienteServiceImpl clienteServiceImpl;

    private Cliente cliente;

    @BeforeEach
    public void Iniciar() {
    cliente = new Cliente(
        12312312,                // rut (int)
        '3',                     // dv  (char)
        "tucuman",               // pnombre
        "anda",                  // snombre
        "Mur",                   // apPaterno
        "Murray",                // apMaterno
        99999994,                // teléfono (int)
        LocalDate.of(1976, 2, 19),// nacimiento
        "Cliente",               // permiso
        1L,                      // id  (Long)
        "Comprador Compulsivo",  // perfil
        "tumurrayto",            // nick
        "Siempre Viva",          // calle
        556,                     // número de casa
        "Providencia"            // comuna
        );
    }

    @Test
    public void findByAllTest(){
        List<Cliente> lista = Arrays.asList(cliente);
        when(clienteRepository.findAll()).thenReturn(lista);
        List<Cliente> resultado = clienteServiceImpl.findByAll();
        assertEquals(1, resultado.size());
        verify(clienteRepository).findAll();

    }

    @Test
    public void findByIdTest(){
        when(clienteRepository.findById(1L)).thenReturn(Optional.of(cliente));
        Optional<Cliente> resultado = clienteServiceImpl.findById(1L);
        assertTrue(resultado.isPresent());
        assertEquals("Providencia", resultado.get().getComuna());
        verify(clienteRepository).findById(1L);
    }

    @Test
    public void saveTest(){
        when(clienteRepository.save(any(Cliente.class))).thenReturn(cliente);
        Cliente resultado = clienteServiceImpl.save(cliente);
        assertNotNull(resultado);
        assertEquals("Providencia", resultado.getComuna());
        verify(clienteRepository).save(cliente);
    }

    @Test
    public void deleteFuncionaTest() {
        when(clienteRepository.findById(1L)).thenReturn(Optional.of(cliente));
        Optional<Cliente> resultado = clienteServiceImpl.delete(cliente);
        assertTrue(resultado.isPresent());
        assertEquals(cliente, resultado.get());
        verify(clienteRepository).delete(cliente);
    }

    @Test
    public void deleteNoFuncionaTest() {
        when(clienteRepository.findById(1L)).thenReturn(Optional.empty());
        Optional<Cliente> resultado = clienteServiceImpl.delete(cliente);
        assertTrue(resultado.isEmpty());
        verify(clienteRepository).findById(1L);
        verify(clienteRepository, never()).delete(any(Cliente.class)); 
    }



}
