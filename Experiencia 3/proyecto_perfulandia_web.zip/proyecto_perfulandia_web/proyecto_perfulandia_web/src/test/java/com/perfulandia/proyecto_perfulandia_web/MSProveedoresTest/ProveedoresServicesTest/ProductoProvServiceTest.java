package com.perfulandia.proyecto_perfulandia_web.MSProveedoresTest.ProveedoresServicesTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorEntities.ProductoProv;
import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorRepositories.ProductoProvRepository;
import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorServices.ProductoProvServiceImpl;

@SpringBootTest
public class ProductoProvServiceTest {

    @Mock
    private ProductoProvRepository productoProvRepository;

    @InjectMocks
    private ProductoProvServiceImpl productoProvServiceImpl;

    private ProductoProv productoProv;

    @BeforeEach
    public void iniciar(){
        productoProv = new ProductoProv(1L, 1L, 1L, 1000, LocalTime.of(2,0), 10);
    }

    @Test
    public void findByAllTest(){
        List<ProductoProv> lista = Arrays.asList(productoProv);
        when(productoProvRepository.findAll()).thenReturn(lista);
        List<ProductoProv> resultado = productoProvServiceImpl.findByAll();
        assertEquals(1, resultado.size());
        verify(productoProvRepository).findAll();

    }

    @Test
    public void findByIdTest(){
        when(productoProvRepository.findById(1L)).thenReturn(Optional.of(productoProv));
        Optional<ProductoProv> resultado = productoProvServiceImpl.findById(1L);
        assertTrue(resultado.isPresent());
        assertEquals(10, resultado.get().getCantProdxMayor());
        verify(productoProvRepository).findById(1L);
    }

    @Test
    public void saveTest(){
        when(productoProvRepository.save(any(ProductoProv.class))).thenReturn(productoProv);
        ProductoProv resultado = productoProvServiceImpl.save(productoProv);
        assertNotNull(resultado);
        assertEquals(10, resultado.getCantProdxMayor());
        verify(productoProvRepository).save(productoProv);
    }

    @Test
    public void deleteFuncionaTest() {
        when(productoProvRepository.findById(1L)).thenReturn(Optional.of(productoProv));
        Optional<ProductoProv> resultado = productoProvServiceImpl.delete(productoProv);
        assertTrue(resultado.isPresent());
        assertEquals(productoProv, resultado.get());
        verify(productoProvRepository).delete(productoProv);
    }

    @Test
    public void deleteNoFuncionaTest() {
        when(productoProvRepository.findById(1L)).thenReturn(Optional.empty());
        Optional<ProductoProv> resultado = productoProvServiceImpl.delete(productoProv);
        assertTrue(resultado.isEmpty());
        verify(productoProvRepository).findById(1L);
        verify(productoProvRepository, never()).delete(any(ProductoProv.class)); 
    }

}
