package com.perfulandia.proyecto_perfulandia_web.MSPermisosTest.PermisosRestControllerTest;

import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.when;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfulandia.proyecto_perfulandia_web.MSPermisos.PermisoEntities.Permiso;
import com.perfulandia.proyecto_perfulandia_web.MSPermisos.PermisoServices.PermisoServicesImpl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;

@SpringBootTest
@AutoConfigureMockMvc
public class PermisoRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private PermisoServicesImpl permisoservicesImpl;

    private List<Permiso> permisosLista;


    @Test
    public void verPermisosTest() throws Exception{
        when(permisoservicesImpl.findByAll()).thenReturn(permisosLista);
        mockMvc.perform(get("/api/permiso")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    }


    @Test
    public void verUnPermiso(){
        Permiso unPermiso = new Permiso(1L, "Cliente", "PERMISOS BASICOS");
        try {
            when(permisoservicesImpl.findById(1L)).thenReturn(Optional.of(unPermiso));
            mockMvc.perform(get("/api/permiso/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        }catch (Exception ex){
            fail("Error en el testintg "+ ex.getMessage());
        }
    }


    @Test
    public void permisoNoExiste() throws Exception{
        when(permisoservicesImpl.findById(100L)).thenReturn(Optional.empty());
        mockMvc.perform(get("/api/permiso/100")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isNotFound());

    }


    @Test
    public void crearPermisosTest() throws Exception{
        Permiso unPermiso = new Permiso(null, "permisos", "PERMISOS NULOS");
        Permiso otroPermiso = new Permiso(9L, "permisos", "PERMISOS NULOS");
        when(permisoservicesImpl.save(any(Permiso.class))).thenReturn(otroPermiso);
        mockMvc.perform(post("/api/permiso")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(unPermiso)))
            .andExpect(status().isCreated());
    }

    @Test
    public void modificarPermisoTest() throws Exception {
        Permiso permisoActualizadoRequest = new Permiso(1L, "Cliente", "PERMISOS AVANZADOS");
        Permiso permisoActualizadoResponse = new Permiso(1L, "Cliente", "PERMISOS AVANZADOS");
        when(permisoservicesImpl.findById(1L))
            .thenReturn(Optional.of(new Permiso(1L, "Cliente", "PERMISOS BASICOS")));
        when(permisoservicesImpl.save(any(Permiso.class)))
            .thenReturn(permisoActualizadoResponse);
        mockMvc.perform(put("/api/permiso/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(permisoActualizadoRequest)))
            .andExpect(status().isOk());
}


   @Test
    public void eliminarPermisoTest() throws Exception {
        Permiso permisoAEliminar = new Permiso(1L, "Cliente", "PERMISOS BASICOS");
        when(permisoservicesImpl.delete(any(Permiso.class)))
            .thenReturn(Optional.of(permisoAEliminar));
        mockMvc.perform(delete("/api/permiso/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(permisoAEliminar)))
            .andExpect(status().isOk()); 

    }

}
