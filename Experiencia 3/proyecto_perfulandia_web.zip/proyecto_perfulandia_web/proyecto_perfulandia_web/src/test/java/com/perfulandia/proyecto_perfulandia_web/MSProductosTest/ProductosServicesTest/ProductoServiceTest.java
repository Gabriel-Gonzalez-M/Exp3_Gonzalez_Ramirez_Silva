package com.perfulandia.proyecto_perfulandia_web.MSProductosTest.ProductosServicesTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.perfulandia.proyecto_perfulandia_web.MSProductos.ProductoEntities.Producto;
import com.perfulandia.proyecto_perfulandia_web.MSProductos.ProductoRepositories.ProductoRepository;
import com.perfulandia.proyecto_perfulandia_web.MSProductos.ProductoServices.ProductoServicesImpl;

@SpringBootTest
public class ProductoServiceTest {

    @Mock
    private ProductoRepository productoRepository;

    @InjectMocks
    private ProductoServicesImpl productoServicesImpl;

    private Producto producto;

    @BeforeEach
    public void iniciar(){
        producto = new Producto(1L, "BLUE NIGHT", "Herbal Aromatica", 30000, 10, "LBEL", 100, "bluenight", "Masculino", "Hombre", "Herbal");

    }

    @Test
    public void findByAllTest(){
        List<Producto> lista = Arrays.asList(producto);
        when(productoRepository.findAll()).thenReturn(lista);
        List<Producto> resultado = productoServicesImpl.findByAll();
        assertEquals(1, resultado.size());
        verify(productoRepository).findAll();

    }

    @Test
    public void findByIdTest(){
        when(productoRepository.findById(1L)).thenReturn(Optional.of(producto));
        Optional <Producto> resultado = productoServicesImpl.findById(1L);
        assertTrue(resultado.isPresent());
        assertEquals("BLUE NIGHT", resultado.get().getNombre());
        verify(productoRepository).findById(1L);
    }

    @Test
    public void saveTest(){
        when(productoRepository.save(any(Producto.class))).thenReturn(producto);
        Producto resultado = productoServicesImpl.save(producto);
        assertNotNull(resultado);
        assertEquals("BLUE NIGHT", resultado.getNombre());
        verify(productoRepository).save(producto);
    }

      @Test
    public void deleteFuncionaTest() {
        when(productoRepository.findById(1L)).thenReturn(Optional.of(producto));
        Optional<Producto> resultado = productoServicesImpl.delete(producto);
        assertTrue(resultado.isPresent());
        assertEquals(producto, resultado.get());
        verify(productoRepository).delete(producto);
    }

    @Test
    public void deleteNoFuncionaTest() {
        when(productoRepository.findById(1L)).thenReturn(Optional.empty());
        Optional<Producto> resultado = productoServicesImpl.delete(producto);
        assertTrue(resultado.isEmpty());
        verify(productoRepository).findById(1L);
        verify(productoRepository, never()).delete(any(Producto.class)); 
    }

}



