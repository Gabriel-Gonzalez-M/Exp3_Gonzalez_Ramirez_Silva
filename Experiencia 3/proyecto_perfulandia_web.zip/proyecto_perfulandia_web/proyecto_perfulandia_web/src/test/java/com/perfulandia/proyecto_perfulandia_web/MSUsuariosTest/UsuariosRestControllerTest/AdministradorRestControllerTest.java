package com.perfulandia.proyecto_perfulandia_web.MSUsuariosTest.UsuariosRestControllerTest;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioEntities.Administrador;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioServices.AdministradorServiceImpl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.ArgumentMatchers.any;

@SpringBootTest
@AutoConfigureMockMvc
public class AdministradorRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private AdministradorServiceImpl administradorServiceImpl;

    private List<Administrador> administradorLista;

     


    @Test
    public void verAdministradorTest() throws Exception{
        when(administradorServiceImpl.findByAll()).thenReturn(administradorLista);
        mockMvc.perform(get("/api/administradores")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    }


    @Test
    public void verUnAdministrador() throws Exception {

    Administrador admin = new Administrador(
            18568916,               // rut  (int)
            '6',                    // dv   (char)
            "Giovanni",             // pnombre
            "Antonio",              // snombre
            "Ramirez",              // apPaterno
            "Astudillo",            // apMaterno
            91363897,               // teléfono (int)
            LocalDate.of(1993, 6, 2), // nacimiento (LocalDate)
            "Administrador",        // permiso
            1L,                     // id (Long)
            "activo",               // estado
            "Administrador"         // cargo
    );

    
        when(administradorServiceImpl.findById(1L))
            .thenReturn(Optional.of(admin));
        mockMvc.perform(get("/api/administradores/1")  
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk());
        verify(administradorServiceImpl).findById(1L);
    }



     @Test
    public void administradorNoExiste() throws Exception{
        when(administradorServiceImpl.findById(100L)).thenReturn(Optional.empty());
        mockMvc.perform(get("/api/administradores/100")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isNotFound());

    }

    @Test
    public void crearAdministradorTest() throws Exception {
    Administrador nuevoAdmin = new Administrador(
            18568916,                     // rut
            '6',                          // dv
            "Giovanni",                   // pnombre
            "Antonio",                    // snombre
            "Ramirez",                    // apPaterno
            "Astudillo",                  // apMaterno
            91363897,                     // telefono
            LocalDate.of(1993, 6, 2),     // nacimiento
            "Administrador",              // permiso
            null,                         // id (null al crear)
            "activo",                     // estado
            "Administrador"               // cargo
    );

    Administrador adminGuardado = new Administrador(
            18568916, '6', 
            "Giovanni", 
            "Antonio",
            "Ramirez", 
            "Astudillo", 
            91363897,
            LocalDate.of(1993, 6, 2),
             "Administrador",
            9L,                          
            "activo", 
            "Administrador"
    );

        when(administradorServiceImpl.save(any(Administrador.class)))
            .thenReturn(adminGuardado);

        mockMvc.perform(post("/api/administradores")          
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(nuevoAdmin)))
            .andExpect(status().isCreated());

    }   


@Test
    public void modificarAdministradorTest() throws Exception {

    Administrador adminOriginal = new Administrador(
            18568916, 
            '6',                 // rut, dv
            "Giovanni", 
            "Antonio",         // pnombre, snombre
            "Ramirez", 
            "Astudillo",        // apPaterno, apMaterno
            91363897,                      // teléfono
            LocalDate.of(1993, 6, 2),      // nacimiento
            "Administrador",               // permiso
            1L,                            // id
            "inactivo",                    // estado (valor ANTES de actualizar)
            "Administrador"                // cargo
    );

    Administrador adminRequest = new Administrador(
            18568916, '6', 
            "Giovanni", 
            "Antonio",
            "Ramirez", 
            "Astudillo", 
            91363897,
            LocalDate.of(1993, 6, 2), 
            "Administrador",
            1L,                            // mismo id
            "activo",                      // NUEVO estado
            "Administrador"
    );

    Administrador adminResponse = adminRequest;
    when(administradorServiceImpl.findById(1L))
            .thenReturn(Optional.of(adminOriginal));
    when(administradorServiceImpl.save(any(Administrador.class)))
            .thenReturn(adminResponse);
    mockMvc.perform(put("/api/administradores/1")               
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(adminRequest)))
            .andExpect(status().isOk());
    }


    @Test
    public void eliminarAdministradorTest() throws Exception {

    Administrador adminEliminado = new Administrador(
            18568916, 
            '6', 
            "Giovanni", 
            "Antonio",
            "Ramirez", 
            "Astudillo", 
            91363897,
            LocalDate.of(1993, 6, 2),
            "Administrador",
            1L,               
            "inactivo",
            "Administrador"
    );

    when(administradorServiceImpl.delete(any(Administrador.class)))
            .thenReturn(Optional.of(adminEliminado));
    mockMvc.perform(delete("/api/administradores/1")         
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk());                    
    }





}
