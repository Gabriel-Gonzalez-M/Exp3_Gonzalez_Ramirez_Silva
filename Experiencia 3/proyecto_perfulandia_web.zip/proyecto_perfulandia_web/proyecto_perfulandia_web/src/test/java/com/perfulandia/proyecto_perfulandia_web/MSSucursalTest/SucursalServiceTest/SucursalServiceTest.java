package com.perfulandia.proyecto_perfulandia_web.MSSucursalTest.SucursalServiceTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Sucursal;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalRepositories.SucursalRepository;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalServices.SucursalServiceImpl;

@SpringBootTest
public class SucursalServiceTest {

    @Mock
    private SucursalRepository sucursalRepository;

    @InjectMocks
    private SucursalServiceImpl sucursalServiceImpl;

    private Sucursal sucursal;

    @BeforeEach
    public void Iniciar(){
        sucursal = new Sucursal(
        "sucursal1@perfulandia.cl",       
        "1234",                             
        1L,                                 
        "Perfulandia Meiggs",                 
        "MP010",                              
        "Estación Central 1234",             
        "Santiago",                           
        "Región Metropolitana",              
        "+56 9 1111 1111",                    
        LocalTime.of(10, 0),                 
        LocalTime.of(20, 0),                  
        "Activa",                             
        LocalDate.of(2024, 1, 1),            
        LocalDate.of(2025, 6, 22),            
        "Camila Rojas",                       
        "Sucursal Express",                   
        35,                                  
        "Venta de perfumes, servicio al cliente",
        "Ubicada cerca del terminal de buses"
    );}


    @Test
    public void findByAllTest(){
        List<Sucursal> lista = Arrays.asList(sucursal);
        when(sucursalRepository.findAll()).thenReturn(lista);
        List<Sucursal> resultado = sucursalServiceImpl.findByAll();
        assertEquals(1, resultado.size());
        verify(sucursalRepository).findAll();

    }

    @Test
    public void findByIdTest(){
        when(sucursalRepository.findById(1L)).thenReturn(Optional.of(sucursal));
        Optional<Sucursal> resultado = sucursalServiceImpl.findById(1L);
        assertTrue(resultado.isPresent());
        assertEquals("Perfulandia Meiggs", resultado.get().getNombre());
        verify(sucursalRepository).findById(1L);
    }

    @Test
    public void saveTest(){
        when(sucursalRepository.save(any(Sucursal.class))).thenReturn(sucursal);
        Sucursal resultado = sucursalServiceImpl.save(sucursal);
        assertNotNull(resultado);
        assertEquals("Perfulandia Meiggs", resultado.getNombre());
        verify(sucursalRepository).save(sucursal);
    }

    @Test
    public void deleteFuncionaTest() {
        when(sucursalRepository.findById(1L)).thenReturn(Optional.of(sucursal));
        Optional<Sucursal> resultado = sucursalServiceImpl.delete(sucursal);
        assertTrue(resultado.isPresent());
        assertEquals(sucursal, resultado.get());
        verify(sucursalRepository).delete(sucursal);
    }

    @Test
    public void deleteNoFuncionaTest() {
        when(sucursalRepository.findById(1L)).thenReturn(Optional.empty());
        Optional<Sucursal> resultado = sucursalServiceImpl.delete(sucursal);
        assertTrue(resultado.isEmpty());
        verify(sucursalRepository).findById(1L);
        verify(sucursalRepository, never()).delete(any(Sucursal.class)); 
    }


}
