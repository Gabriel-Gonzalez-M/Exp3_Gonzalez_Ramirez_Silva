package com.perfulandia.proyecto_perfulandia_web.MSProveedoresTest.ProveedoresRestControllerTest;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorEntities.ProductoProv;
import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorServices.ProductoProvServiceImpl;


@SpringBootTest
@AutoConfigureMockMvc
public class ProductoProvRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private ProductoProvServiceImpl productoProvServiceImpl;

    private List<ProductoProv> productoProvLista;

    @Test
    public void verProductosProvTest() throws Exception{
        when(productoProvServiceImpl.findByAll()).thenReturn(productoProvLista);
        mockMvc.perform(get("/api/productoprov")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    }

    @Test
    public void verUnProductoProv(){
        ProductoProv prod = new ProductoProv(1L, 1L, 1L, 1000, LocalTime.of(2,0), 10);
        try {
            when(productoProvServiceImpl.findById(1L)).thenReturn(Optional.of(prod));
            mockMvc.perform(get("/api/productoprov/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        }catch (Exception ex){
            fail("Error en el testintg "+ ex.getMessage());
        }
    }



    @Test
    public void productoProvNoExisteTest() throws Exception {
        when(productoProvServiceImpl.findById(100L)).thenReturn(Optional.empty());
        mockMvc.perform(get("/api/productoprov/100")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    public void crearProductoProvTest() throws Exception {
        ProductoProv prod = new ProductoProv(null, 1L, 1L, 1000, LocalTime.of(2,0), 10);
        ProductoProv prodGuardado = new ProductoProv(2L, 1L, 1L, 1000, LocalTime.of(2,0), 10);
        when(productoProvServiceImpl.save(any(ProductoProv.class))).thenReturn(prodGuardado);
        mockMvc.perform(post("/api/productoprov")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(prod)))
                .andExpect(status().isCreated());
    }

    @Test
    public void modificarProductoProvTest() throws Exception {
        ProductoProv prodActualizadoRequest = new ProductoProv(1L, 2L, 2L, 3000, LocalTime.of(3,0), 20);
        ProductoProv prodActualizadoResponse = new ProductoProv(1L, 2L, 2L, 3000, LocalTime.of(3,0), 20);
        when(productoProvServiceImpl.findById(1L))
            .thenReturn(Optional.of(new ProductoProv(2L, 1L, 1L, 1000, LocalTime.of(2,0), 10)));
        when(productoProvServiceImpl.save(any(ProductoProv.class)))
            .thenReturn(prodActualizadoResponse);
        mockMvc.perform(put("/api/productoprov/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(prodActualizadoRequest)))
            .andExpect(status().isOk());
    }


   @Test
    public void eliminarProductoProvTest() throws Exception {
        ProductoProv productoProvAEliminar = new ProductoProv(null, 1L, 1L, 1000, LocalTime.of(2,0), 10);
        when(productoProvServiceImpl.delete(any(ProductoProv.class)))
            .thenReturn(Optional.of(productoProvAEliminar));
        mockMvc.perform(delete("/api/productoprov/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(productoProvAEliminar)))
            .andExpect(status().isOk()); 

    }
}
