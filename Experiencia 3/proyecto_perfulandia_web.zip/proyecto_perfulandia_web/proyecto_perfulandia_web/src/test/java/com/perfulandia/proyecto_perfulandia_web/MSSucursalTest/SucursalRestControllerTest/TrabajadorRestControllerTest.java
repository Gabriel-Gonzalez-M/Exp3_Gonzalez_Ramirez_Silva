package com.perfulandia.proyecto_perfulandia_web.MSSucursalTest.SucursalRestControllerTest;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Trabajador;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalServices.TrabajadorServiceImpl;

@SpringBootTest
@AutoConfigureMockMvc
public class TrabajadorRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private TrabajadorServiceImpl trabajadorServiceImpl;

    private List<Trabajador> trabajadorList;


    @Test
    public void verTrabajorTest() throws Exception{
        when(trabajadorServiceImpl.findByAll()).thenReturn(trabajadorList);
        mockMvc.perform(get("/api/trabajadores")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    }


    @Test
    public void verUnTrabajador(){
        Trabajador unTrabajador = new Trabajador(1L, 1L, "Empleado", 1L);
        try {
            when(trabajadorServiceImpl.findById(1L)).thenReturn(Optional.of(unTrabajador));
            mockMvc.perform(get("/api/trabajadores/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        }catch (Exception ex){
            fail("Error en el testintg "+ ex.getMessage());
        }
    }


    @Test
    public void trabajadorNoExiste() throws Exception{
        when(trabajadorServiceImpl.findById(100L)).thenReturn(Optional.empty());
        mockMvc.perform(get("/api/trabajadores/100")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isNotFound());

    }


    @Test
    public void crearTrabajadorTest() throws Exception{
        Trabajador unTrabajador = new Trabajador(null, 1L, "Gerente", 1L);
        Trabajador otroTrabajador = new Trabajador(1L, 1L, "Gerente", 1L);
        when(trabajadorServiceImpl.save(any(Trabajador.class))).thenReturn(otroTrabajador);
        mockMvc.perform(post("/api/trabajadores")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(unTrabajador)))
            .andExpect(status().isCreated());
    }

    @Test
    public void modificarTrabajadorTest() throws Exception {
        Trabajador trabajadorActualizadoRequest = new Trabajador(1L, 1L, "Gerente", 1L);
        Trabajador trabajadorActualizadoResponse = new Trabajador(1L, 1L, "Gerente", 1L);
        when(trabajadorServiceImpl.findById(1L))
            .thenReturn(Optional.of(new Trabajador(1L, 1L, "Empleado", 1L)));
        when(trabajadorServiceImpl.save(any(Trabajador.class)))
            .thenReturn(trabajadorActualizadoResponse);
        mockMvc.perform(put("/api/trabajadores/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(trabajadorActualizadoRequest)))
            .andExpect(status().isOk());
}


   @Test
    public void eliminarTrabajadorTest() throws Exception {
        Trabajador trabajadorAEliminar = new Trabajador(1L, 1L, "Empleado", 1L);
        when(trabajadorServiceImpl.delete(any(Trabajador.class)))
            .thenReturn(Optional.of(trabajadorAEliminar));
        mockMvc.perform(delete("/api/trabajadores/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(trabajadorAEliminar)))
            .andExpect(status().isOk()); 

    }

}
