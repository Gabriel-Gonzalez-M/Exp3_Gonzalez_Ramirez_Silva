package com.perfulandia.proyecto_perfulandia_web.MSSucursalTest.SucursalRestControllerTest;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Inventario;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalServices.InventarioServiceImpl;

@SpringBootTest
@AutoConfigureMockMvc
public class InventarioRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private InventarioServiceImpl inventarioServiceImpl;

    private List<Inventario> inventarioLista;

    @Test
    public void verInventarioTest() throws Exception{
        when(inventarioServiceImpl.findByAll()).thenReturn(inventarioLista);
        mockMvc.perform(get("/api/inventarios")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    }


    @Test
    public void verUnInventario(){
        Inventario unInventario = new Inventario(1L, 1L, 1L, 100);
        try {
            when(inventarioServiceImpl.findById(1L)).thenReturn(Optional.of(unInventario));
            mockMvc.perform(get("/api/inventarios/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        }catch (Exception ex){
            fail("Error en el testintg "+ ex.getMessage());
        }
    }


    @Test
    public void inventarioNoExiste() throws Exception{
        when(inventarioServiceImpl.findById(100L)).thenReturn(Optional.empty());
        mockMvc.perform(get("/api/inventarios/100")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isNotFound());

    }


    @Test
    public void crearInventarioTest() throws Exception{
        Inventario unInventario = new Inventario(null, 1L, 1L, 0);
        Inventario otroInventario = new Inventario(1L, 1L, 1L, 0);
        when(inventarioServiceImpl.save(any(Inventario.class))).thenReturn(otroInventario);
        mockMvc.perform(post("/api/inventarios")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(unInventario)))
            .andExpect(status().isCreated());
    }

    @Test
    public void modificarInventarioTest() throws Exception {
        Inventario inventarioActualizadoRequest = new Inventario(1L, 1L, 1L, 200);
        Inventario inventarioActualizadoResponse = new Inventario(1L, 1L, 1L, 200);
        when(inventarioServiceImpl.findById(1L))
            .thenReturn(Optional.of(new Inventario(1L, 1L, 1L, 100)));
        when(inventarioServiceImpl.save(any(Inventario.class)))
            .thenReturn(inventarioActualizadoResponse);
        mockMvc.perform(put("/api/inventarios/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(inventarioActualizadoRequest)))
            .andExpect(status().isOk());
}


   @Test
    public void eliminarInventarioTest() throws Exception {
        Inventario inventarioAEliminar = new Inventario(1L, 1L, 1L, 100);
        when(inventarioServiceImpl.delete(any(Inventario.class)))
            .thenReturn(Optional.of(inventarioAEliminar));
        mockMvc.perform(delete("/api/inventarios/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(inventarioAEliminar)))
            .andExpect(status().isOk()); 

    }

}
