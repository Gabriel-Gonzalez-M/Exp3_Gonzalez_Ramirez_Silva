package com.perfulandia.proyecto_perfulandia_web.MSSucursalTest.SucursalServiceTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Inventario;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalRepositories.InventarioRepository;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalServices.InventarioServiceImpl;

@SpringBootTest
public class InventarioServiceTest {

    @Mock
    private InventarioRepository inventarioRepository;

    @InjectMocks
    private InventarioServiceImpl inventarioServiceImpl;

    private Inventario inventario;

    @BeforeEach
    public void Iniciar(){
        inventario = new Inventario(1L, 1L, 1L, 100);
    }

     @Test
    public void findByAllTest(){
        List<Inventario> lista = Arrays.asList(inventario);
        when(inventarioRepository.findAll()).thenReturn(lista);
        List<Inventario> resultado = inventarioServiceImpl.findByAll();
        assertEquals(1, resultado.size());
        verify(inventarioRepository).findAll();

    }

    @Test
    public void findByIdTest(){
        when(inventarioRepository.findById(1L)).thenReturn(Optional.of(inventario));
        Optional<Inventario> resultado = inventarioServiceImpl.findById(1L);
        assertTrue(resultado.isPresent());
        assertEquals(100, resultado.get().getStock());
        verify(inventarioRepository).findById(1L);
    }

    @Test
    public void saveTest(){
        when(inventarioRepository.save(any(Inventario.class))).thenReturn(inventario);
        Inventario resultado = inventarioServiceImpl.save(inventario);
        assertNotNull(resultado);
        assertEquals(100, resultado.getStock());
        verify(inventarioRepository).save(inventario);
    }

    @Test
    public void deleteFuncionaTest() {
        when(inventarioRepository.findById(1L)).thenReturn(Optional.of(inventario));
        Optional<Inventario> resultado = inventarioServiceImpl.delete(inventario);
        assertTrue(resultado.isPresent());
        assertEquals(inventario, resultado.get());
        verify(inventarioRepository).delete(inventario);
    }

    @Test
    public void deleteNoFuncionaTest() {
        when(inventarioRepository.findById(1L)).thenReturn(Optional.empty());
        Optional<Inventario> resultado = inventarioServiceImpl.delete(inventario);
        assertTrue(resultado.isEmpty());
        verify(inventarioRepository).findById(1L);
        verify(inventarioRepository, never()).delete(any(Inventario.class)); 
    }
}
