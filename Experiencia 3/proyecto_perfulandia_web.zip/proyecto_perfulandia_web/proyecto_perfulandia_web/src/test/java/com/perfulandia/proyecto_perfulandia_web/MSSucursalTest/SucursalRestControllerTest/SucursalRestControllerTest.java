package com.perfulandia.proyecto_perfulandia_web.MSSucursalTest.SucursalRestControllerTest;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Sucursal;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalServices.SucursalServiceImpl;

@SpringBootTest
@AutoConfigureMockMvc
public class SucursalRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private SucursalServiceImpl sucursalServiceImpl;

    private List<Sucursal> sucursalLista;

    @Test
    public void verSucusalTest() throws Exception{
        when(sucursalServiceImpl.findByAll()).thenReturn(sucursalLista);
        mockMvc.perform(get("/api/sucursales")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    }


    @Test
    public void verUnaSucursal(){
        Sucursal unaSucursal = new Sucursal(
        "sucursal1@perfulandia.cl",       
        "1234",                             
        1L,                                 
        "Perfulandia Meiggs",                 
        "MP010",                              
        "Estación Central 1234",             
        "Santiago",                           
        "Región Metropolitana",              
        "+56 9 1111 1111",                    
        LocalTime.of(10, 0),                 
        LocalTime.of(20, 0),                  
        "Activa",                             
        LocalDate.of(2024, 1, 1),            
        LocalDate.of(2025, 6, 22),            
        "Camila Rojas",                       
        "Sucursal Express",                   
        35,                                  
        "Venta de perfumes, servicio al cliente",
        "Ubicada cerca del terminal de buses"
        );
        try {
            when(sucursalServiceImpl.findById(1L)).thenReturn(Optional.of(unaSucursal));
            mockMvc.perform(get("/api/sucursales/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        }catch (Exception ex){
            fail("Error en el testintg "+ ex.getMessage());
        }
    }


    @Test
    public void sucursalNoExiste() throws Exception{
        when(sucursalServiceImpl.findById(100L)).thenReturn(Optional.empty());
        mockMvc.perform(get("/api/sucursales/100")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isNotFound());

    }


    @Test
    public void crearSucursalTest() throws Exception{
        Sucursal unaSucursal = new Sucursal("sucursal1@perfulandia.cl","1234",null, "Perfulandia Meiggs","MP010","Estación Central 1234","Santiago","Región Metropolitana","+56 9 1111 1111",LocalTime.of(10, 0),LocalTime.of(20, 0),"Activa",LocalDate.of(2024, 1, 1),LocalDate.of(2025, 6, 22),"Camila Rojas","Sucursal Express",35,"Venta de perfumes, servicio al cliente","Ubicada cerca del terminal de buses");
        Sucursal otraSucursal = new Sucursal("sucursal1@perfulandia.cl","1234",1L, "Perfulandia Meiggs","MP010","Estación Central 1234","Santiago","Región Metropolitana","+56 9 1111 1111",LocalTime.of(10, 0),LocalTime.of(20, 0),"Activa",LocalDate.of(2024, 1, 1),LocalDate.of(2025, 6, 22),"Camila Rojas","Sucursal Express",35,"Venta de perfumes, servicio al cliente","Ubicada cerca del terminal de buses");
        when(sucursalServiceImpl.save(any(Sucursal.class))).thenReturn(otraSucursal);
        mockMvc.perform(post("/api/sucursales")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(unaSucursal)))
            .andExpect(status().isCreated());
    }

    @Test
    public void modificarSucursalTest() throws Exception {
        Sucursal sucursalActualizadoRequest = new Sucursal("sucursal1@perfulandia.cl","1234",1L, "Perfulandia Viña","MP010","Estación Central 1234","Santiago","Región Metropolitana","+56 9 1111 1111",LocalTime.of(10, 0),LocalTime.of(20, 0),"Activa",LocalDate.of(2024, 1, 1),LocalDate.of(2025, 6, 22),"Camila Rojas","Sucursal Express",35,"Venta de perfumes, servicio al cliente","Ubicada cerca del terminal de buses");
        Sucursal sucursalActualizadoResponse = new Sucursal("sucursal1@perfulandia.cl","1234",1L, "Perfulandia Viña","MP010","Estación Central 1234","Santiago","Región Metropolitana","+56 9 1111 1111",LocalTime.of(10, 0),LocalTime.of(20, 0),"Activa",LocalDate.of(2024, 1, 1),LocalDate.of(2025, 6, 22),"Camila Rojas","Sucursal Express",35,"Venta de perfumes, servicio al cliente","Ubicada cerca del terminal de buses");

        when(sucursalServiceImpl.findById(1L))
            .thenReturn(Optional.of(new Sucursal("sucursal1@perfulandia.cl","1234",1L, "Perfulandia Meiggs","MP010","Estación Central 1234","Santiago","Región Metropolitana","+56 9 1111 1111",LocalTime.of(10, 0),LocalTime.of(20, 0),"Activa",LocalDate.of(2024, 1, 1),LocalDate.of(2025, 6, 22),"Camila Rojas","Sucursal Express",35,"Venta de perfumes, servicio al cliente","Ubicada cerca del terminal de buses")));
        when(sucursalServiceImpl.save(any(Sucursal.class)))
            .thenReturn(sucursalActualizadoResponse);
        mockMvc.perform(put("/api/sucursales/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(sucursalActualizadoRequest)))
            .andExpect(status().isOk());
}


   @Test
    public void eliminarSucursalTest() throws Exception {
        Sucursal sucursalAEliminar = new Sucursal("sucursal1@perfulandia.cl","1234",1L, "Perfulandia Meiggs","MP010","Estación Central 1234","Santiago","Región Metropolitana","+56 9 1111 1111",LocalTime.of(10, 0),LocalTime.of(20, 0),"Activa",LocalDate.of(2024, 1, 1),LocalDate.of(2025, 6, 22),"Camila Rojas","Sucursal Express",35,"Venta de perfumes, servicio al cliente","Ubicada cerca del terminal de buses");
        when(sucursalServiceImpl.delete(any(Sucursal.class)))
            .thenReturn(Optional.of(sucursalAEliminar));
        mockMvc.perform(delete("/api/sucursales/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(sucursalAEliminar)))
            .andExpect(status().isOk()); 

    }

}
