package com.perfulandia.proyecto_perfulandia_web.MSUsuariosTest.UsuariosServicesTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioEntities.Empleado;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioRepositories.EmpleadoRepository;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioServices.EmpleadoServicesImpl;

@SpringBootTest
public class EmpleadoServiceTest {

    @Mock
    private EmpleadoRepository empleadoRepository;

    @InjectMocks
    private EmpleadoServicesImpl empleadoServicesImpl;

    private Empleado empleado;

    @BeforeEach
    public void Iniciar() {
    empleado = new Empleado(
        33333333,            // rut (int)
        '3',                 // dv  (char)
        "Miyarai",           // pnombre
        "Camila",            // snombre
        "Gomez",             // apPaterno
        "Sepulveda",         // apMaterno
        99999991,            // teléfono (int)
        LocalDate.of(1993, 2, 10), // nacimiento
        "Empleado",          // permiso
        1L,                  // id  (Long)
        LocalDate.of(2024, 5, 10), // fechaIngreso
        "Activo",            // estado
        "Empleado",          // cargo
        "Mañana"             // turno
    );
    }


    @Test
    public void findByAllTest(){
        List<Empleado> lista = Arrays.asList(empleado);
        when(empleadoRepository.findAll()).thenReturn(lista);
        List<Empleado> resultado = empleadoServicesImpl.findByAll();
        assertEquals(1, resultado.size());
        verify(empleadoRepository).findAll();

    }

    @Test
    public void findByIdTest(){
        when(empleadoRepository.findById(1L)).thenReturn(Optional.of(empleado));
        Optional<Empleado> resultado = empleadoServicesImpl.findById(1L);
        assertTrue(resultado.isPresent());
        assertEquals("Miyarai", resultado.get().getPnombre());
        verify(empleadoRepository).findById(1L);
    }

    @Test
    public void saveTest(){
        when(empleadoRepository.save(any(Empleado.class))).thenReturn(empleado);
        Empleado resultado = empleadoServicesImpl.save(empleado);
        assertNotNull(resultado);
        assertEquals("Miyarai", resultado.getPnombre());
        verify(empleadoRepository).save(empleado);
    }

    @Test
    public void deleteFuncionaTest() {
        when(empleadoRepository.findById(1L)).thenReturn(Optional.of(empleado));
        Optional<Empleado> resultado = empleadoServicesImpl.delete(empleado);
        assertTrue(resultado.isPresent());
        assertEquals(empleado, resultado.get());
        verify(empleadoRepository).delete(empleado);
    }

    @Test
    public void deleteNoFuncionaTest() {
        when(empleadoRepository.findById(1L)).thenReturn(Optional.empty());
        Optional<Empleado> resultado = empleadoServicesImpl.delete(empleado);
        assertTrue(resultado.isEmpty());
        verify(empleadoRepository).findById(1L);
        verify(empleadoRepository, never()).delete(any(Empleado.class)); 
    }



}
