package com.perfulandia.proyecto_perfulandia_web.MSUsuariosTest.UsuariosRestControllerTest;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioEntities.Cliente;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioServices.ClienteServiceImpl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import static org.mockito.ArgumentMatchers.any;


@SpringBootTest
@AutoConfigureMockMvc
public class ClienteRestControllerTest {


    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private ClienteServiceImpl clienteServiceImpl;

    private List<Cliente> clienteLista;


    @Test
    public void verClientesTest() throws Exception{
        when(clienteServiceImpl.findByAll()).thenReturn(clienteLista);
        mockMvc.perform(get("/api/clientes")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    }

    @Test
    public void verUnCliente() throws Exception {

    Cliente unCliente = new Cliente(
            12312312,                 // rut
            '3',                      // dv
            "tucuman",                // pnombre
            "anda",                   // snombre
            "Mur",                    // apPaterno
            "Murray",                 // apMaterno
            99999994,                 // teléfono
            LocalDate.of(1976, 2, 19),// nacimiento
            "Cliente",                // permiso
            1L,                       // id
            "Comprador Compulsivo",   // perfil
            "tumurrayto",             // nick
            "Siempre Viva",           // calle
            556,                      // número casa
            "Providencia"             // comuna
    );

    when(clienteServiceImpl.findById(1L))
            .thenReturn(Optional.of(unCliente));
    mockMvc.perform(get("/api/clientes/1")            
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk());
    verify(clienteServiceImpl).findById(1L);
    }


    @Test
    public void clienteNoExiste() throws Exception{
        when(clienteServiceImpl.findById(100L)).thenReturn(Optional.empty());
        mockMvc.perform(get("/api/clientes/100")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isNotFound());

    }


    @Test
    public void crearClienteTest() throws Exception {

    Cliente nuevoCliente = new Cliente(
            12312312, 
            '3',         // rut, dv
            "tucuman",
            "anda",     // pnombre, snombre
            "Mur", 
            "Murray",       // apPaterno, apMaterno
            99999994,              // teléfono
            LocalDate.of(1976, 2, 19), // nacimiento
            "Cliente",             // permiso
            null,                  // id (null al crear)
            "Comprador Compulsivo",// perfil
            "tumurrayto",          // nick
            "Siempre Viva",        // calle
            556,                   // número casa
            "Providencia"          // comuna
    );

    
    Cliente clienteGuardado = new Cliente(
            12312312, 
            '3', 
            "tucuman",
            "anda",
            "Mur",
            "Murray", 
            99999994,
            LocalDate.of(1976, 2, 19), 
            "Cliente",
            9L,                       
            "Comprador Compulsivo", 
            "tumurrayto",
            "Siempre Viva",
            556, 
            "Providencia"
    );
    when(clienteServiceImpl.save(any(Cliente.class)))
            .thenReturn(clienteGuardado);
    mockMvc.perform(post("/api/clientes")                     
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(nuevoCliente)))
            .andExpect(status().isCreated());
    }


    @Test
    public void modificarClienteTest() throws Exception {

    Cliente clienteOriginal = new Cliente(
            12312312, 
            '3', 
            "tucuman", 
            "anda",
            "Mur", 
            "Murray", 
            99999994,
            LocalDate.of(1976, 2, 19), 
            "Cliente",
            1L, 
            "Comprador Compulsivo", 
            "tumurrayto",
            "Siempre Viva", 
            556, "Providencia"
    );

    Cliente clienteRequest = new Cliente(
            12312312, 
            '3', 
            "tucuman", 
            "anda",
            "Mur", 
            "Murray", 
            99999994,
            LocalDate.of(1976, 2, 19), 
            "Cliente",
            1L, 
            "Comprador VIP",          
            "tumurrayto", 
            "Siempre Viva", 
            556, 
            "Providencia"
    );


    Cliente clienteResponse = clienteRequest; 
    when(clienteServiceImpl.findById(1L))
            .thenReturn(Optional.of(clienteOriginal));
    when(clienteServiceImpl.save(any(Cliente.class)))
            .thenReturn(clienteResponse);
    mockMvc.perform(put("/api/clientes/1")                  
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(clienteRequest)))
            .andExpect(status().isOk());                     
    verify(clienteServiceImpl).findById(1L);
    verify(clienteServiceImpl).save(any(Cliente.class));
}


@Test
public void eliminarClienteTest() throws Exception {

    Cliente clienteAEliminar = new Cliente(
            12312312, 
            '3', 
            "tucuman", 
            "anda",
            "Mur", 
            "Murray", 
            99999994,
            LocalDate.of(1976, 2, 19), 
            "Cliente",
            1L, 
            "Comprador Compulsivo", 
            "tumurrayto",
            "Siempre Viva", 
            556, 
            "Providencia"
    );

    when(clienteServiceImpl.delete(any(Cliente.class)))
            .thenReturn(Optional.of(clienteAEliminar));
    mockMvc.perform(delete("/api/clientes/1")         
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk());                
    verify(clienteServiceImpl).delete(any(Cliente.class));
}


}
