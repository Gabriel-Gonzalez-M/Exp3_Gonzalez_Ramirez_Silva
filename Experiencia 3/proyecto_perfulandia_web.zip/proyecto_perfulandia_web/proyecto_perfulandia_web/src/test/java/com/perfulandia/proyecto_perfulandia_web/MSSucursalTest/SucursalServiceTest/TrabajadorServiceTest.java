package com.perfulandia.proyecto_perfulandia_web.MSSucursalTest.SucursalServiceTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalEntities.Trabajador;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalRepositories.TrabajadorRepository;
import com.perfulandia.proyecto_perfulandia_web.MSSucursal.SucursalServices.TrabajadorServiceImpl;

@SpringBootTest
public class TrabajadorServiceTest {

    @Mock
    private TrabajadorRepository trabajadorRepository;

    @InjectMocks
    private TrabajadorServiceImpl trabajadorServiceImpl;

    private Trabajador trabajador;

    @BeforeEach
    public void Iniciar(){
        trabajador = new Trabajador(1L, 1L, "Empleado", 1L);
    }

     @Test
    public void findByAllTest(){
        List<Trabajador> lista = Arrays.asList(trabajador);
        when(trabajadorRepository.findAll()).thenReturn(lista);
        List<Trabajador> resultado = trabajadorServiceImpl.findByAll();
        assertEquals(1, resultado.size());
        verify(trabajadorRepository).findAll();

    }

    @Test
    public void findByIdTest(){
        when(trabajadorRepository.findById(1L)).thenReturn(Optional.of(trabajador));
        Optional<Trabajador> resultado = trabajadorServiceImpl.findById(1L);
        assertTrue(resultado.isPresent());
        assertEquals("Empleado", resultado.get().getTipoTrabajador());
        verify(trabajadorRepository).findById(1L);
    }

    @Test
    public void saveTest(){
        when(trabajadorRepository.save(any(Trabajador.class))).thenReturn(trabajador);
        Trabajador resultado = trabajadorServiceImpl.save(trabajador);
        assertNotNull(resultado);
        assertEquals("Empleado", resultado.getTipoTrabajador());
        verify(trabajadorRepository).save(trabajador);
    }

    @Test
    public void deleteFuncionaTest() {
        when(trabajadorRepository.findById(1L)).thenReturn(Optional.of(trabajador));
        Optional<Trabajador> resultado = trabajadorServiceImpl.delete(trabajador);
        assertTrue(resultado.isPresent());
        assertEquals(trabajador, resultado.get());
        verify(trabajadorRepository).delete(trabajador);
    }

    @Test
    public void deleteNoFuncionaTest() {
        when(trabajadorRepository.findById(1L)).thenReturn(Optional.empty());
        Optional<Trabajador> resultado = trabajadorServiceImpl.delete(trabajador);
        assertTrue(resultado.isEmpty());
        verify(trabajadorRepository).findById(1L);
        verify(trabajadorRepository, never()).delete(any(Trabajador.class)); 
    }
}
