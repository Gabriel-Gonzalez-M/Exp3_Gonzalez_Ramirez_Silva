package com.perfulandia.proyecto_perfulandia_web.MSVentasTest.VentasRestControllerTest;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaEntities.Venta;
import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaServices.VentaServiceImpl;


@SpringBootTest
@AutoConfigureMockMvc
public class VentaRestControllerTest {


    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private VentaServiceImpl ventaServiceImpl;

    private List<Venta> ventaLista;


    @Test
    public void verVentasTest() throws Exception{
        when(ventaServiceImpl.findByAll()).thenReturn(ventaLista);
        mockMvc.perform(get("/api/venta")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    }




    @Test
    public void verUnaVenta() throws Exception {

        Venta unaVenta = new Venta(
            1L,           // id
            25000,        // total
            0.00f,        // descuento
            1L,           // idCliente
            true,         // presencial
            1L,           // idEmpleado
            "CYBER25",    // codigoPromo
            2L            // idSucursal
    );

        try {
            when(ventaServiceImpl.findById(1L)).thenReturn(Optional.of(unaVenta));
            mockMvc.perform(get("/api/venta/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        }catch (Exception ex){
            fail("Error en el testing "+ ex.getMessage());
        }
    }


    @Test
    public void ventaNoExiste() throws Exception{
        when(ventaServiceImpl.findById(100L)).thenReturn(Optional.empty());
        mockMvc.perform(get("/api/venta/100")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isNotFound());

    }


    @Test
    public void crearVentaTest() throws Exception {

    Venta unaVenta = new Venta(
            null,          // id  (null al crear)
            25000,         // total
            0.00f,         // descuento
            1L,            // idCliente
            true,          // presencial
            1L,            // idEmpleado
            "CYBER25",     // codigoPromo
            2L             // idSucursal
    );

    Venta otraVenta = new Venta(
            9L,            
            25000,
            0.00f,
            1L,
            true,
            1L,
            "CYBER25",
            2L
    );

    when(ventaServiceImpl.save(any(Venta.class))).thenReturn(otraVenta);
    mockMvc.perform(post("/api/venta")                    
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(unaVenta)))
            .andExpect(status().isCreated());             
    }


    @Test
    public void modificarVentaTest() throws Exception {

    Venta ventaActualizadaRequest = new Venta(
            1L,          // id
            22000,       // total actualizado
            1500.0f,     // descuento actualizado
            1L,          // idCliente (sin cambios)
            true,        // presencial
            1L,          // idEmpleado
            "CYBER25",   // codigoPromo
            2L           // idSucursal
    );

    Venta ventaExistente = new Venta(
            1L,
            25000,
            0.0f,
            1L,
            true,
            1L,
            "CYBER25",
            2L
    );

    Venta ventaActualizadaResponse = ventaActualizadaRequest; 
    when(ventaServiceImpl.findById(1L)).thenReturn(Optional.of(ventaExistente));
    when(ventaServiceImpl.save(any(Venta.class))).thenReturn(ventaActualizadaResponse);
    mockMvc.perform(put("/api/venta/1")             
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(ventaActualizadaRequest)))
            .andExpect(status().isOk());            
}


@Test
void eliminarVentaTest() throws Exception {

    Venta ventaAEliminar = new Venta(
            1L,          // id
            25000,       // total
            0.0f,        // descuento
            1L,          // idCliente
            true,        // presencial
            1L,          // idEmpleado
            "CYBER25",   // codigoPromo
            2L           // idSucursal
    );

    when(ventaServiceImpl.delete(any(Venta.class)))
            .thenReturn(Optional.of(ventaAEliminar));
    mockMvc.perform(delete("/api/venta/1")         
            .contentType(MediaType.APPLICATION_JSON)) 
            .andExpect(status().isOk());             
}




    







    

}
