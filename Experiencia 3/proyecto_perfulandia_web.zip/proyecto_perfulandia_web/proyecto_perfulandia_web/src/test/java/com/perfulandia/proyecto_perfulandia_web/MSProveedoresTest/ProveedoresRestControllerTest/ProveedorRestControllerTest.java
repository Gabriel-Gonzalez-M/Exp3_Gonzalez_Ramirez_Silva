package com.perfulandia.proyecto_perfulandia_web.MSProveedoresTest.ProveedoresRestControllerTest;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorEntities.Proveedor;
import com.perfulandia.proyecto_perfulandia_web.MSProveedores.ProveedorServices.ProveedorServiceImpl;


@SpringBootTest
@AutoConfigureMockMvc
public class ProveedorRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private ProveedorServiceImpl proveedorServiceImpl;

    private List<Proveedor> proveedorLista;

   @Test
    public void verProveedorTest() throws Exception{
        when(proveedorServiceImpl.findByAll()).thenReturn(proveedorLista);
        mockMvc.perform(get("/api/proveedor")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    }


    @Test
    public void verUnProveedorTest() throws Exception {
        Proveedor proveedor = new Proveedor(1L, "Juan", "Pérez", "Calle Falsa", 123, "Santiago", "Chilena", 987654321, "juan@mail.com", "1234", "web.com", LocalTime.of(9,0), LocalTime.of(18,0));
        when(proveedorServiceImpl.findById(1L)).thenReturn(Optional.of(proveedor));
        mockMvc.perform(get("/api/proveedor/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void verUnProductoProv(){
        Proveedor proveedor = new Proveedor(1L, "Juan", "Pérez", "Calle Falsa", 123, "Santiago", "Chilena", 987654321, "juan@mail.com", "1234", "web.com", LocalTime.of(9,0), LocalTime.of(18,0));
        try {
            when(proveedorServiceImpl.findById(1L)).thenReturn(Optional.of(proveedor));
            mockMvc.perform(get("/api/proveedor/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        }catch (Exception ex){
            fail("Error en el testintg "+ ex.getMessage());
        }
    }

    @Test
    public void proveedorNoExisteTest() throws Exception {
        when(proveedorServiceImpl.findById(100L)).thenReturn(Optional.empty());
        mockMvc.perform(get("/api/proveedor/100")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    public void crearProveedorTest() throws Exception {
        Proveedor proveedor = new Proveedor(null, "Juan", "Pérez", "Calle Falsa", 123, "Santiago", "Chilena", 987654321, "juan@mail.com", "1234", "web.com", LocalTime.of(9,0), LocalTime.of(18,0));
        Proveedor proveedorGuardado = new Proveedor(2L, "Juan", "Pérez", "Calle Falsa", 123, "Santiago", "Chilena", 987654321, "juan@mail.com", "1234", "web.com", LocalTime.of(9,0), LocalTime.of(18,0));
        when(proveedorServiceImpl.save(any(Proveedor.class))).thenReturn(proveedorGuardado);
        mockMvc.perform(post("/api/proveedor")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(proveedor)))
                .andExpect(status().isCreated());
    }


    @Test
    public void modificarProveedorTest() throws Exception {
        Proveedor proveedorActualizadoRequest = new Proveedor(1L, "Juan", "Pérez", "Nueva Calle", 456, "Providencia", "Chilena", 987654321, "juan@mail.com", "1234", "web.com", LocalTime.of(10,0), LocalTime.of(19,0));
        Proveedor proveedorActualizadoResponse = new Proveedor(1L, "Juan", "Pérez", "Nueva Calle", 456, "Providencia", "Chilena", 987654321, "juan@mail.com", "1234", "web.com", LocalTime.of(10,0), LocalTime.of(19,0));
        
        when(proveedorServiceImpl.findById(1L))
            .thenReturn(Optional.of(new Proveedor(1L, "Juan", "Pérez", "Calle Falsa", 123, "Santiago", "Chilena", 987654321, "juan@mail.com", "1234", "web.com", LocalTime.of(9,0), LocalTime.of(18,0))));
        when(proveedorServiceImpl.save(any(Proveedor.class)))
            .thenReturn(proveedorActualizadoResponse);
        mockMvc.perform(put("/api/proveedor/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(proveedorActualizadoRequest)))
            .andExpect(status().isOk());
}


   @Test
    public void eliminarProveedorTest() throws Exception {
        Proveedor proveedorAELiminar = new Proveedor(1L, "Juan", "Pérez", "Calle Falsa", 123, "Santiago", "Chilena", 987654321, "juan@mail.com", "1234", "web.com", LocalTime.of(9,0), LocalTime.of(18,0));
        when(proveedorServiceImpl.delete(any(Proveedor.class)))
            .thenReturn(Optional.of(proveedorAELiminar));
        mockMvc.perform(delete("/api/proveedor/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(proveedorAELiminar)))
            .andExpect(status().isOk()); 

    }



}
