package com.perfulandia.proyecto_perfulandia_web.MSUsuariosTest.UsuariosRestControllerTest;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioEntities.Gerente;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioServices.GerenteServicesImpl;

@SpringBootTest
@AutoConfigureMockMvc
public class GerenteRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private GerenteServicesImpl gerenteServicesImpl;

    private List<Gerente> gerenteLista;

    @Test
    public void verGerenteTest() throws Exception{
        when(gerenteServicesImpl.findByAll()).thenReturn(gerenteLista);
        mockMvc.perform(get("/api/gerentes")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    }




    @Test
    public void verUnGerente() throws Exception {

    Gerente unGerente = new Gerente(
            15487123,                  // rut
            '0',                       // dv
            "Agusto",                  // pnombre
            "Descanso",                // snombre
            "Pinocho",                 // apPaterno
            "Humbarte",                // apMaterno
            99999988,                  // teléfono
            LocalDate.of(1915, 11, 25),// nacimiento
            "Gerente",                 // permiso
            1L,                        // id
            LocalDate.of(2022, 11, 24),// fechaIngreso
            "Inactivo",               // estado
            "Mañana"                   // turno
    );

    when(gerenteServicesImpl.findById(1L)).thenReturn(Optional.of(unGerente));
    mockMvc.perform(get("/api/gerentes/1")        
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    verify(gerenteServicesImpl).findById(1L);
    }



    
    @Test
    public void permisoNoExiste() throws Exception{
        when(gerenteServicesImpl.findById(100L)).thenReturn(Optional.empty());
        mockMvc.perform(get("/api/gerentes/100")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isNotFound());

    }


    @Test
    public void crearGerenteTest() throws Exception {

    Gerente gerenteRequest = new Gerente(
            15487123, 
            '0',                 // rut, dv
            "Agusto", 
            "Descanso",          // pnombre, snombre
            "Pinocho", 
            "Humbarte",         // apPaterno, apMaterno
            99999988,                      // teléfono
            LocalDate.of(1915, 11, 25),    // nacimiento
            "Gerente",                     // permiso
            null,                          // id (null al crear)
            LocalDate.of(2022, 11, 24),    // fechaIngreso
            "Inactivo",                    // estado
            "Mañana"                       // turno
    );
  
    Gerente gerenteResponse = new Gerente(
            15487123, 
            '0', 
            "Agusto", 
            "Descanso",
            "Pinocho", 
            "Humbarte", 
            99999988,
            LocalDate.of(1915, 11, 25), 
            "Gerente",
            9L,                             
            LocalDate.of(2022, 11, 24),
            "Inactivo", 
            "Mañana"
    );

    when(gerenteServicesImpl.save(any(Gerente.class)))
            .thenReturn(gerenteResponse);
    mockMvc.perform(post("/api/gerentes")                 
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(gerenteRequest)))
            .andExpect(status().isCreated());          
    }





    @Test
    public void modificarGerenteTest() throws Exception {
    Gerente gerenteActualizadoRequest = new Gerente(
            15487123, 
            '0',                 // rut, dv
            "Agusto", 
            "Descanso",          // pnombre, snombre
            "Pinocho", 
            "Humbarte",         // apPaterno, apMaterno
            99999988,                      // teléfono
            LocalDate.of(1915, 11, 25),    // nacimiento
            "Gerente",                     // permiso
            1L,                            // id
            LocalDate.of(2022, 11, 24),    // fechaIngreso
            "Activo",                      
            "Tarde"                        
    );
    Gerente gerenteActualizadoResponse = gerenteActualizadoRequest; 
    Gerente gerenteExistente = new Gerente(
            15487123, 
            '0', 
            "Agusto", 
            "Descanso",
            "Pinocho", 
            "Humbarte", 
            99999988,
            LocalDate.of(1915, 11, 25), 
            "Gerente",
            1L,
            LocalDate.of(2022, 11, 24),
            "Inactivo",   
            "Mañana"      
    );

    when(gerenteServicesImpl.findById(1L)).thenReturn(Optional.of(gerenteExistente));
    when(gerenteServicesImpl.save(any(Gerente.class))).thenReturn(gerenteActualizadoResponse);
    mockMvc.perform(put("/api/gerentes/1")                 
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(gerenteActualizadoRequest)))
            .andExpect(status().isOk());          
    }





    @Test
    public void eliminarGerenteTest() throws Exception {

    Gerente gerenteAEliminar = new Gerente(
            15487123, 
            '0',                 // rut, dv
            "Agusto", 
            "Descanso",          // pnombre, snombre
            "Pinocho", 
            "Humbarte",         // apPaterno, apMaterno
            99999988,                      // teléfono
            LocalDate.of(1915, 11, 25),    // nacimiento
            "Gerente",                     // permiso
            1L,                            // id
            LocalDate.of(2022, 11, 24),    // fecha de ingreso
            "Inactivo",                    // estado
            "Mañana"                       // turno
    );

    when(gerenteServicesImpl.delete(any(Gerente.class)))
            .thenReturn(Optional.of(gerenteAEliminar));
    mockMvc.perform(delete("/api/gerentes/1")          
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk());              
}





}
