package com.perfulandia.proyecto_perfulandia_web.MSPermisosTest.PermisosServicesTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.perfulandia.proyecto_perfulandia_web.MSPermisos.PermisoEntities.Permiso;
import com.perfulandia.proyecto_perfulandia_web.MSPermisos.PermisoRepositories.PermisoRepository;
import com.perfulandia.proyecto_perfulandia_web.MSPermisos.PermisoServices.PermisoServicesImpl;

@SpringBootTest
public class PermisoServiceTest {

    @Mock
    private PermisoRepository permisoRepository;

    @InjectMocks
    private PermisoServicesImpl permisoServicesImpl;

    private Permiso permiso;

    @BeforeEach
    public void Iniciar(){
        permiso = new Permiso(1L, "Cliente", "PERMISOS BASICOS");
    }

    @Test
    public void findByAllTest(){
        List<Permiso> lista = Arrays.asList(permiso);
        when(permisoRepository.findAll()).thenReturn(lista);
        List<Permiso> resultado = permisoServicesImpl.findByAll();
        assertEquals(1, resultado.size());
        verify(permisoRepository).findAll();

    }

    @Test
    public void findByIdTest(){
        when(permisoRepository.findById(1L)).thenReturn(Optional.of(permiso));
        Optional<Permiso> resultado = permisoServicesImpl.findById(1L);
        assertTrue(resultado.isPresent());
        assertEquals("Cliente", resultado.get().getNombre());
        verify(permisoRepository).findById(1L);
    }

    @Test
    public void saveTest(){
        when(permisoRepository.save(any(Permiso.class))).thenReturn(permiso);
        Permiso resultado = permisoServicesImpl.save(permiso);
        assertNotNull(resultado);
        assertEquals("Cliente", resultado.getNombre());
        verify(permisoRepository).save(permiso);
    }

    @Test
    public void deleteFuncionaTest() {
        when(permisoRepository.findById(1L)).thenReturn(Optional.of(permiso));
        Optional<Permiso> resultado = permisoServicesImpl.delete(permiso);
        assertTrue(resultado.isPresent());
        assertEquals(permiso, resultado.get());
        verify(permisoRepository).delete(permiso);
    }

    @Test
    public void deleteNoFuncionaTest() {
        when(permisoRepository.findById(1L)).thenReturn(Optional.empty());
        Optional<Permiso> resultado = permisoServicesImpl.delete(permiso);
        assertTrue(resultado.isEmpty());
        verify(permisoRepository).findById(1L);
        verify(permisoRepository, never()).delete(any(Permiso.class)); 
    }

}
