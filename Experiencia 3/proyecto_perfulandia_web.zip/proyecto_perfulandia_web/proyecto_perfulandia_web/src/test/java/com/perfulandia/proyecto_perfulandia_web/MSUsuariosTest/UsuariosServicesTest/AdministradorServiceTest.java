package com.perfulandia.proyecto_perfulandia_web.MSUsuariosTest.UsuariosServicesTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioEntities.Administrador;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioRepositories.AdministradorRepository;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioServices.AdministradorServiceImpl;

@SpringBootTest
public class AdministradorServiceTest {

    @Mock
    private AdministradorRepository administradorRepository;

    @InjectMocks
    private AdministradorServiceImpl administradorServiceImpl;

    private Administrador administrador;

    @BeforeEach
    public void Iniciar() {
        administrador = new Administrador(
                18568916,                     // rut (int)
                '6',                          // dv  (char)
                "Giovanni",                   // pnombre
                "Antonio",                    // snombre
                "Ramirez",                    // apPaterno
                "Astudillo",                  // apMaterno
                91363897,                     // telefono
                LocalDate.of(1993, 6, 2),     // nacimiento
                "Administrador",              // permiso
                1L,                           // id
                "inactivo",                   // estado
                "Administrador"               // cargo
        );
    
    }

    @Test
    public void findByAllTest(){
        List<Administrador> lista = Arrays.asList(administrador);
        when(administradorRepository.findAll()).thenReturn(lista);
        List<Administrador> resultado = administradorServiceImpl.findByAll();
        assertEquals(1, resultado.size());
        verify(administradorRepository).findAll();

    }


    @Test
    public void findByIdTest(){
        when(administradorRepository.findById(1L)).thenReturn(Optional.of(administrador));
        Optional<Administrador> resultado = administradorServiceImpl.findById(1L);
        assertTrue(resultado.isPresent());
        assertEquals("Giovanni", resultado.get().getPnombre());
        verify(administradorRepository).findById(1L);
    }


    @Test
    public void saveTest(){
        when(administradorRepository.save(any(Administrador.class))).thenReturn(administrador);
        Administrador resultado = administradorServiceImpl.save(administrador);
        assertNotNull(resultado);
        assertEquals("Giovanni", resultado.getPnombre());
        verify(administradorRepository).save(administrador);
    }


    @Test
    public void deleteFuncionaTest() {
        when(administradorRepository.findById(1L)).thenReturn(Optional.of(administrador));
        Optional<Administrador> resultado = administradorServiceImpl.delete(administrador);
        assertTrue(resultado.isPresent());
        assertEquals(administrador, resultado.get());
        verify(administradorRepository).delete(administrador);
    }

    @Test
    public void deleteNoFuncionaTest() {
        when(administradorRepository.findById(1L)).thenReturn(Optional.empty());
        Optional<Administrador> resultado = administradorServiceImpl.delete(administrador);
        assertTrue(resultado.isEmpty());
        verify(administradorRepository).findById(1L);
        verify(administradorRepository, never()).delete(any(Administrador.class)); 
    }


}
