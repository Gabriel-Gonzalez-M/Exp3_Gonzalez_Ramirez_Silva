package com.perfulandia.proyecto_perfulandia_web.MSVentasTest.VentasRestControllerTest;


import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.when;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaEntities.Carrito;
import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaServices.CarritoServiceImpl;

import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;

@SpringBootTest
@AutoConfigureMockMvc
public class CarritoRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private CarritoServiceImpl carritoServiceImpl;

    private List<Carrito> carritosLista;

    @Test
    public void verCarritoTest() throws Exception{
        when(carritoServiceImpl.findByAll()).thenReturn(carritosLista);
        mockMvc.perform(get("/api/carrito")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    }

    @Test
    public void verUnCarrito(){
        Carrito unCarrito = new Carrito(1L, 1L, 1L);
        try {
            when(carritoServiceImpl.findById(1L)).thenReturn(Optional.of(unCarrito));
            mockMvc.perform(get("/api/carrito/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        }catch (Exception ex){
            fail("Error en el testintg "+ ex.getMessage());
        }
    }


    @Test
    public void carritoNoExiste() throws Exception{
        when(carritoServiceImpl.findById(100L)).thenReturn(Optional.empty());
        mockMvc.perform(get("/api/carrito/100")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isNotFound());

    }


    @Test
    public void crearCarritoTest() throws Exception{
        Carrito unCarrito = new Carrito(null, 1L, 1L);
        Carrito otroCarrito = new Carrito(9L, 1L, 1L);
        when(carritoServiceImpl.save(any(Carrito.class))).thenReturn(otroCarrito);
        mockMvc.perform(post("/api/carrito")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(unCarrito)))
            .andExpect(status().isCreated());
    }

    @Test
    public void modificarCarritoTest() throws Exception {
        Carrito carritoActualizadoRequest = new Carrito(1L, 1L, 1L);
        Carrito carritoActualizadoResponse = new Carrito(1L, 1L, 1L);
        when(carritoServiceImpl.findById(1L))
            .thenReturn(Optional.of(new Carrito(1L, 1L, 2L)));
        when(carritoServiceImpl.save(any(Carrito.class)))
            .thenReturn(carritoActualizadoResponse);
        mockMvc.perform(put("/api/carrito/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(carritoActualizadoRequest)))
            .andExpect(status().isOk());
    }


   @Test
    public void eliminarCarritoTest() throws Exception {
        Carrito carritoAEliminar = new Carrito(1L, 1L, 1L);
        when(carritoServiceImpl.delete(any(Carrito.class)))
            .thenReturn(Optional.of(carritoAEliminar));
        mockMvc.perform(delete("/api/carrito/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(carritoAEliminar)))
            .andExpect(status().isOk()); 

    }



}
