package com.perfulandia.proyecto_perfulandia_web.MSProductosTest.ProductosRestControllerTest;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfulandia.proyecto_perfulandia_web.MSProductos.ProductoEntities.Producto;
import com.perfulandia.proyecto_perfulandia_web.MSProductos.ProductoServices.ProductoServicesImpl;

@SpringBootTest
@AutoConfigureMockMvc
public class ProductoRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private ProductoServicesImpl productoServicesImpl;

    private List<Producto> productoLista;

    @Test
    public void verProductosTest() throws Exception{
        when(productoServicesImpl.findByAll()).thenReturn(productoLista);
        mockMvc.perform(get("/api/productos")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());
    }


    @Test
    public void verUnProducto(){
        Producto unProducto = new Producto(1L, "BLUE NIGHT", "Herbal Aromatica", 30000, 10, "LBEL", 100, "bluenight", "Masculino", "Hombre", "Herbal");
        try{
            when(productoServicesImpl.findById(1L)).thenReturn(Optional.of(unProducto));
            mockMvc.perform(get("/api/productos/1")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk());
        }catch(Exception ex){
            fail("Erros en el testing "+ ex.getMessage());
        }
    }


    @Test
    public void productoNoExiste() throws Exception{
        when(productoServicesImpl.findById(100L)).thenReturn(Optional.empty());
        mockMvc.perform(get("/api/productos/100")
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNotFound());
    }


    @Test
    public void crearProductoTest() throws Exception{
        Producto unProducto = new Producto(null, "BLUE NIGHT", "Herbal Aromatica", 30000, 10, "LBEL", 100, "bluenight", "Masculino", "Hombre", "Herbal");
        Producto otroProducto = new Producto(4L, "VANILLA SHIMER SHINE", "Herbal Aromatica", 30000, 10, "LBEL", 100, "bluenight", "Masculino", "Hombre", "Herbal");
        when(productoServicesImpl.save(any(Producto.class))).thenReturn(otroProducto);
        mockMvc.perform(post("/api/productos")
        .contentType(MediaType.APPLICATION_JSON)
        .content(objectMapper.writeValueAsString(unProducto)))
        .andExpect(status().isCreated());
    }


    @Test
    public void modificarPersoTest() throws Exception{
        Producto productoActualizadoRequest = new Producto(1L, "BLUE NIGHT", "Herbal Aromatica", 30000, 10, "LBEL", 100, "bluenight", "Masculino", "Hombre", "Herbal");
        Producto productoActualizadoResponse = new Producto(1L, "BLUE NIGHT", "Herbal Aromatica", 30000, 10, "LBEL", 100, "bluenight", "Masculino", "Hombre", "Herbal");
        when(productoServicesImpl.findById(1L))
            .thenReturn(Optional.of(new Producto(1L, "VANILLA SHIMER SHINE", "Herbal Aromatica", 20000, 0, "LBEL", 100, "bluenight", "Femenino", "Mujer", "Herbal")));
        when(productoServicesImpl.save(any(Producto.class)))
            .thenReturn(productoActualizadoResponse);
        mockMvc.perform(put("/api/productos/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(productoActualizadoRequest)))
            .andExpect(status().isOk());
    }



    @Test
    public void eliminarProductoTest() throws Exception {
        Producto productoAEliminar = new Producto(1L, "BLUE NIGHT", "Herbal Aromatica", 30000, 10, "LBEL", 100, "bluenight", "Masculino", "Hombre", "Herbal");
        when(productoServicesImpl.delete(any(Producto.class)))
            .thenReturn(Optional.of(productoAEliminar));
        mockMvc.perform(delete("/api/productos/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(productoAEliminar)))
            .andExpect(status().isOk()); 

    }



}
