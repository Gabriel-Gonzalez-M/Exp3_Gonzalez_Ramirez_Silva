package com.perfulandia.proyecto_perfulandia_web.MSUsuariosTest.UsuariosServicesTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioEntities.Gerente;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioRepositories.GerenteRepository;
import com.perfulandia.proyecto_perfulandia_web.MSUsuarios.UsuarioServices.GerenteServicesImpl;

@SpringBootTest
public class GerenteServiceTest {

    @Mock
    private GerenteRepository gerenteRepository;

    @InjectMocks
    private GerenteServicesImpl gerenteServicesImpl;

    private Gerente gerente;

    @BeforeEach
    public void Iniciar() {
    gerente = new Gerente(
        15487123,              // rut
        '0',                   // dv
        "Agusto",              // pnombre
        "Descanso",            // snombre
        "Pinocho",             // apPaterno
        "Humbarte",            // apMaterno
        99999988,              // teléfono
        LocalDate.of(1915, 11, 25), // nacimiento
        "Gerente",             // permiso
        1L,                    // id
        LocalDate.of(2022, 11, 24), // fechaIngreso
        "Inactivo",            // estado
        "Mañana"               // turno
    );
    }


    @Test
    public void findByAllTest(){
        List<Gerente> lista = Arrays.asList(gerente);
        when(gerenteRepository.findAll()).thenReturn(lista);
        List<Gerente> resultado = gerenteServicesImpl.findByAll();
        assertEquals(1, resultado.size());
        verify(gerenteRepository).findAll();

    }

    @Test
    public void findByIdTest(){
        when(gerenteRepository.findById(1L)).thenReturn(Optional.of(gerente));
        Optional<Gerente> resultado = gerenteServicesImpl.findById(1L);
        assertTrue(resultado.isPresent());
        assertEquals("Agusto", resultado.get().getPnombre());
        verify(gerenteRepository).findById(1L);
    }

    @Test
    public void saveTest(){
        when(gerenteRepository.save(any(Gerente.class))).thenReturn(gerente);
        Gerente resultado = gerenteServicesImpl.save(gerente);
        assertNotNull(resultado);
        assertEquals("Agusto", resultado.getPnombre());
        verify(gerenteRepository).save(gerente);
    }

    @Test
    public void deleteFuncionaTest() {
        when(gerenteRepository.findById(1L)).thenReturn(Optional.of(gerente));
        Optional<Gerente> resultado = gerenteServicesImpl.delete(gerente);
        assertTrue(resultado.isPresent());
        assertEquals(gerente, resultado.get());
        verify(gerenteRepository).delete(gerente);
    }

    @Test
    public void deleteNoFuncionaTest() {
        when(gerenteRepository.findById(1L)).thenReturn(Optional.empty());
        Optional<Gerente> resultado = gerenteServicesImpl.delete(gerente);
        assertTrue(resultado.isEmpty());
        verify(gerenteRepository).findById(1L);
        verify(gerenteRepository, never()).delete(any(Gerente.class)); 
    }


}
