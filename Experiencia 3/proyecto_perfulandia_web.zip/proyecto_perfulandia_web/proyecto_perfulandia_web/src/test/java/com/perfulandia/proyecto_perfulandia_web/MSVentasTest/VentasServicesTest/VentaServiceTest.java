package com.perfulandia.proyecto_perfulandia_web.MSVentasTest.VentasServicesTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaEntities.Venta;
import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaRepositories.VentaRepository;
import com.perfulandia.proyecto_perfulandia_web.MSVenta.VentaServices.VentaServiceImpl;

@SpringBootTest
public class VentaServiceTest {

    @Mock
    private VentaRepository ventaRepository;

    @InjectMocks
    private VentaServiceImpl ventaServiceImpl;

    private Venta venta;


    @BeforeEach
    public void iniciar() {
    venta = new Venta(
        1L,          // id
        25000,       // total
        0.0f,        // descuento
        1L,          // idCliente
        true,        // presencial
        1L,          // idEmpleado
        "CYBER25",   // codigoPromo
        2L           // idSucursal
    );
    }


    @Test
    public void findByAllTest(){
        List<Venta> lista = Arrays.asList(venta);
        when(ventaRepository.findAll()).thenReturn(lista);
        List<Venta> resultado = ventaServiceImpl.findByAll();
        assertEquals(1, resultado.size());
        verify(ventaRepository).findAll();

    }

    @Test
    public void findByIdTest(){
        when(ventaRepository.findById(1L)).thenReturn(Optional.of(venta));
        Optional<Venta> resultado = ventaServiceImpl.findById(1L);
        assertTrue(resultado.isPresent());
        assertEquals("CYBER25", resultado.get().getCodigoPromo());
        verify(ventaRepository).findById(1L);
    }

    @Test
    public void saveTest(){
        when(ventaRepository.save(any(Venta.class))).thenReturn(venta);
        Venta resultado = ventaServiceImpl.save(venta);
        assertNotNull(resultado);
        assertEquals("CYBER25", resultado.getCodigoPromo());
        verify(ventaRepository).save(venta);
    }

    @Test
    public void deleteFuncionaTest() {
        when(ventaRepository.findById(1L)).thenReturn(Optional.of(venta));
        Optional<Venta> resultado = ventaServiceImpl.delete(venta);
        assertTrue(resultado.isPresent());
        assertEquals(venta, resultado.get());
        verify(ventaRepository).delete(venta);
    }

    @Test
    public void deleteNoFuncionaTest() {
        when(ventaRepository.findById(1L)).thenReturn(Optional.empty());
        Optional<Venta> resultado = ventaServiceImpl.delete(venta);
        assertTrue(resultado.isEmpty());
        verify(ventaRepository).findById(1L);
        verify(ventaRepository, never()).delete(any(Venta.class)); 
    }


}
